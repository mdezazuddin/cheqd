<?php $page= "home";?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name=”description”>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<title>xyz</title>

<!-- normalize -->
<link rel="stylesheet" href="assets/css/normalize.min.css">
<!-- fav-icon -->    
<link rel="shortcut icon" href="assets/image/brand1.png"> 
<!-- Bootstrap 4.4.1-->
<link rel="stylesheet" href="assets/bootstrap-4.4.1/css/bootstrap.min.css">
<!-- Font-Awesome-5 -->
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
<!-- google-fonts -->    
<link href="https://fonts.googleapis.com/css2?family=Nunito:ital,wght@0,200;0,300;0,400;0,600;0,700;0,800;0,900;1,200;1,300;1,400;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
<!-- hover-master -->
<link rel="stylesheet" href="assets/Hover-master/css/hover.css">
<!-- poppup video -->
<link rel="stylesheet" href="assets/poppup-video-jquary-3.2.1/grt-youtube-popup.min.css">
<!-- style.css -->
<link rel="stylesheet" href="assets/css/style.css">
<!-- swipre-master -->
<link rel="stylesheet" href="assets/swiper-master/package/css/swiper.css">

</head>
<body>
    <main>
        <div class="web-market1 pb-5">
            <!-- header -->
            <header>
                <?php include("header.php"); ?>
            </header>
            
            <!-- Contents 14 -->
            <section class="py-5 mb-5">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-12 col-lg-6 pr-md-5 ml-md-auto text-left">
                            <div class="type-wrap">
                                
                            </div>
                            <div class="card bg-light btn-round pl-0 pr-0 col-xl-7">
                                <div class="card-body mx-auto text-center p-2 d-flex">
                                    <span class="mr-3"><small class="bg-danger pb-1 pl-2 pr-2 btn-round text-white">v2.2</small></span>
                                    <p class="mb-1"><small>Build <span class="text-blue">anything</span> you want - Landrick.</small></p>
                                </div>
                            </div>
                            <h1 class="mt-4">Get taxes & compliances done 

                                <div id="typed-strings">
                                    <span class="text-blue">Webapps</span>
                                    <p class="text-blue">Studio</p>
                                    <p class="text-blue">Agency</p>
                                    <p class="text-blue">Technology</p>
                                </div>
                                <span class="text-blue" id="typed" style="white-space:pre;"></span>

                                on time.</h1>
                            
                            <p class="mt-3 p2">Get 2x productive by automatically drafting taxes & compliance liabilities from regular business operations such as, invoicing, expensing, employee management and payroll.</p>
                            <p><a class="btn btn btns10 rounded-lg px-4 py-2 mt-2" href="#"><small><i class="fas fa-store mr-2"></i></small> Free Trial</a></p>
                            <span><a href="#">Schedule a live demo</a> for an in-depth understanding.</span>
                        </div>
                        <div class="col-12 col-lg-6 mt-4">
                            <span class="layers">
                                <p class="mt-5"><a href="#" youtubeid="qLCLvzTGFVM" class="btn btn-light p-4 pxt2 rounded-circle youtube-link"><i class="fa fa-play text-blue"></i></a></p>
                            </span>
                            <img class="w-100 mb-5" src="assets/image//marketing.png">
                        </div>
                    </div>
                </div>
            </section>
        </div>


        <div class="pt-md-5 pb-md-5">
            <hr class="my-5">
        </div>


        <!-- Feature 9 -->
        <section class="pb-5">
            <div class="container">
                <div class="row text-center">
                    <div class="col-md-6 mx-auto">
                        <h2>Features</h2>
                        <p class="mt-3">Start working with <b class="text-blue">Landrick</b> that can provide everything you need to generate awareness, drive traffic, connect.</p>
                    </div>
                </div>
        
                <div class="row">
                    <div class="col-12 col-lg-4 col-md-6 mt-4 parent2">
                        <div class="parent2 mttl1">
                            <div class="child2 anim-des mttl2"><span class="p-5"></span></div>
                            <div class="layers2">
                                <img alt="image" class="w-25 fntts7 mt-4" src="assets/image/pen.svg">
                            </div>
                        </div>
                        <h5>All compliances that matter to your business</h5>
                        <p class="mt-3">GST, TDS, PF, ESI, Profession Tax, MCA, Licenses & many more - all integrated on single platform. You get error free compliance filing, timely reminders, early notification about penalties & charges.</p>
                    </div>
            
                    <div class="col-12 col-lg-4 col-md-6 mt-4 parent2">
                        <div class="parent2 mttl1">
                            <div class="child2 anim-des mttl2"><span class="p-5"></span></div>
                            <div class="layers2">
                                <img alt="image" class="w-25 fntts7 mt-4" src="assets/image/video.svg">
                            </div>
                        </div>
                        <h5>AI based invoicing & expense management</h5>
                        <p class="mt-3">Bookkeeping is superfast and fun. The AI engine allows you to automatically create expense from physical bills. You can also import from other systems e.g. Tally, Quickbooks & even from Excel and see your data in an unified manner.</p>
                    </div>
            
                    <div class="col-12 col-lg-4 col-md-6 mt-4 parent2">
                        <div class="parent2 mttl1">
                            <div class="child2 anim-des mttl2"><span class="p-5"></span></div>
                            <div class="layers2">
                                <img alt="image" class="w-25 fntts7 mt-4" src="assets/image/intellectual.svg">
                            </div>
                        </div>
                        <h5>Employee onboarding, payroll & reimbursements</h5>
                        <p class="mt-3">You get a minimal HRMS with all features you need: employee onboarding, Bank account verification, PAN/Aadhaar verification, salary structure & revision, payroll, form16 & investment declarations.</p>
                    </div>

                    <div class="col-12 col-lg-4 col-md-6 mt-4 parent2">
                        <div class="parent2 mttl1">
                            <div class="child2 anim-des mttl2"><span class="p-5"></span></div>
                            <div class="layers2">
                                <img alt="image" class="w-25 fntts7 mt-4" src="assets/image/user.svg">
                            </div>
                        </div>
                        <h5>Cashflow, receivables & financial analytics</h5>
                        <p class="mt-3">See your growth parameters on numbers and charts. Identify anomalies in your business engine early so that corrective actions can be taken. More control over your business like never before.</p>
                    </div>
            
                    <div class="col-12 col-lg-4 col-md-6 mt-4 parent2">
                        <div class="parent2 mttl1">
                            <div class="child2 anim-des mttl2"><span class="p-5"></span></div>
                            <div class="layers2">
                                <img alt="image" class="w-25 fntts7 mt-4" src="assets/image/calendar.svg">
                            </div>
                        </div>
                        <h5>Daily Reports</h5>
                        <p class="mt-3">Allegedly, a Latin scholar established the origin of the text by established compiling unusual word.</p>
                    </div>
            
                    <div class="col-12 col-lg-4 col-md-6 mt-4 parent2">
                        <div class="parent2 mttl1">
                            <div class="child2 anim-des mttl2"><span class="p-5"></span></div>
                            <div class="layers2">
                                <img alt="image" class="w-25 fntts7 mt-4" src="assets/image/sand-clock.svg">
                            </div>
                        </div>
                        <h5>Real Time Zone</h5>
                        <p class="mt-3">It seems that only fragments of the original text remain in the Lorem Ipsum texts the original used today.</p>
                    </div>
                </div>
            </div>
        </section>


        <!-- Call to Action 13 -->
        <section class="bg-one mt-5 mb-5">
            <div class="opacity1 py-5">
                <div class="container py-5 justify-content-center align-items-center d-flex">
                    <div class="row justify-content-center py-5 text-white text-center">
                        <div class="col-12 col-md-8">
                            <h2>Stop leaving money on the table.</h2>
                            <p class="mt-3 text-white">Start working with Landrick that can provide everything you need to generate awareness, drive traffic, connect.</p>
                            
                            <p class="mt-5"><a href="#" youtubeid="qLCLvzTGFVM" class="btn btn-outline-light p-4 pxt2 rounded-circle youtube-link"><i class="fa fa-play"></i></a></p>
                        </div>
                    </div>
                </div>
            </div>
        </section>


        <!-- Pricings 5 -->
        <section class="py-5">
            <div class="container">
                <div class="row text-center">
                    <div class="col-md-6 mx-auto">
                        <h2>Choose Simple Pricing</h2>
                        <p class="mt-3">Start working with <b class="text-blue">Landrick</b> that can provide everything you need to generate awareness, drive traffic, connect.</p>
                    </div>
                </div>
        
                <div class="row mt-5 align-items-center">
                    <div class="col-12 col-sm-10 col-md-8 p-3 m-auto col-lg-4 text-center">
                        <div class="bg-light pb-5 pt-5 pl-4 pr-4 rounded-right hvr-grow w-100 card7">
                            <h6 class="font-weight-bold clr2">FREE</h6>
                            <p class="mt-4 mb-5 text-body"><strong><sup class="h5 text-body">$</sup></strong> <strong><sub class="h1">0</sub></strong> <strong><sub class="h4 text-body">/mo</sub></strong></p>
                            <div>
                                <p class="mb-1"><i class="fa fa-check mr-3 text-success"></i><span>Full Access</span></p>
                                <p class="mb-1"><i class="fa fa-check mr-3 text-success"></i><span>Enhanced Security</span></p>
                                <p class="mb-1"><i class="fa fa-check mr-3 text-success"></i><span>Source Files</span></p>
                                <p class="mb-1"><i class="fa fa-check mr-3 text-success"></i><span>1 Domain Free</span></p>
                            </div>
                            <p class="text-center pt-4"><a href="https://www.froala.com" class="btn btn btns9 px-4 py-2 rounded-lg mt-4">Buy Now</a></p>
                        </div>
                    </div>
            
                    <div class="col-12 col-sm-10 col-md-8 ml-auto mr-auto col-lg-4 text-center mt-4 mt-lg-0 sl-1 pt-0 pt-lg-3 pb-0 pb-lg-3 fdb-touch rounded bg-light hvr-grow w-100">
                        <div class="bg-light pb-5 pt-5 pl-4 pr-4 rounded-right card7">
                            <h6 class="font-weight-bold text-blue clr2">STARTER</h6>
                            <p class="mt-4 mb-5 text-body"><strong><sup class="h5 text-body">$</sup></strong> <strong><sub class="h1">39</sub></strong> <strong><sub class="h4 text-body">/mo</sub></strong></p>
                            <div>
                                <p class="mb-1"><i class="fa fa-check mr-3 text-success"></i><span>Full Access</span></p>
                                <p class="mb-1"><i class="fa fa-check mr-3 text-success"></i><span>Enhanced Security</span></p>
                                <p class="mb-1"><i class="fa fa-check mr-3 text-success"></i><span>Source Files</span></p>
                                <p class="mb-1"><i class="fa fa-check mr-3 text-success"></i><span>1 Domain Free</span></p>
                            </div>
                            <p class="text-center pt-4"><a href="https://www.froala.com" class="btn btn btns9 px-4 py-2 rounded-lg mt-4">Get Started</a></p>
                        </div>
                    </div>
            
                    <div class="col-12 col-sm-10 col-md-8 m-auto col-lg-4 text-center">
                        <div class="bg-light pb-5 pt-5 pl-4 pr-4 rounded-right hvr-grow w-100 card7">
                            <h6 class="font-weight-bold clr2">PROFESSIONAL</h6>
                            <p class="mt-4 mb-5 text-body"><strong><sup class="h5 text-body">$</sup></strong> <strong><sub class="h1">59</sub></strong> <strong><sub class="h4 text-body">/mo</sub></strong></p>
                            <div>
                                <p class="mb-1"><i class="fa fa-check mr-3 text-success"></i><span>Full Access</span></p>
                                <p class="mb-1"><i class="fa fa-check mr-3 text-success"></i><span>Enhanced Security</span></p>
                                <p class="mb-1"><i class="fa fa-check mr-3 text-success"></i><span>Source Files</span></p>
                                <p class="mb-1"><i class="fa fa-check mr-3 text-success"></i><span>1 Domain Free</span></p>
                            </div>
                            <p class="text-center pt-4"><a href="https://www.froala.com" class="btn btn btns9 px-4 py-2 rounded-lg mt-4">Try It Now</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </section>


        <!-- Contents 12 -->
        <section class="py-5">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-12 col-md-7">
                        <h2>Your data is 100% <a class="text-blue" href="#">secure</a> in Cheqd.</h2>
                        <p class="mt-3">Start working with <a class="text-blue" href="#">Landrick</a> that can provide everything you need to generate awareness, drive traffic, connect.</p>
                        <div class="mt-4">
                            <p class="mb-1"><i class="far fa-check-circle mr-3 text-success"></i><span>Digital Marketing Solutions for Tomorrow</span></p>
                            <p class="mb-1"><i class="far fa-check-circle mr-3 text-success"></i><span>Our Talented & Experienced Marketing Agency</span></p>
                            <p class="mb-1"><i class="far fa-check-circle mr-3 text-success"></i><span>Create your own skin to match your brand</span></p>
                        </div>
                    </div>
                    <div class="col-12 col-md-5 ml-md-auto mt-4 mt-md-0">
                        <div class="row text-center">
                            <div class="col-md-6">
                                <div class="bg-light py-4 px-2 rounded-lg">
                                    <div class="card-body">
                                        <h2 class="count-this" data-text="%">97</h2>
                                        <h5 class="text-body">In-transit & at-rest encryption</h5>
                                    </div>
                                </div>
                                <div class="bg-blue py-4 mt-3 px-2 rounded-lg">
                                    <div class="card-body text-white">
                                        <h2 class="count-this" data-text="+">15</h2>
                                        <h5 class="">Frequent data backup</h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 mt-5">
                                <div class="bg-success text-white py-4 px-2 rounded-lg">
                                    <div class="card-body">
                                        <h2 class="count-this" data-text="k">12</h2>
                                        <h5 class="">Strict access control</h5>
                                    </div>
                                </div>
                                <div class="bg-light py-4 px-2 mt-3 rounded-lg">
                                    <div class="card-body">
                                        <h2 class="count-this" data-text="%">98</h2>
                                        <h5 class="text-body">Touchless deployment</h5>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>



       <!-- Pricings 5 -->
       <section class="bg-light py-5">
            <div class="container py-5">
                <div class="row text-center">
                    <div class="col-md-6 mx-auto">
                        <h2>Latest News</h2>
                        <p class="mt-3">Start working with <b class="text-blue">Landrick</b> that can provide everything you need to generate awareness, drive traffic, connect.</p>
                    </div>
                </div>
        
                <div class="row align-items-center">
                    <div class="col-12 col-lg-4 mt-5">
                        <div class="shadow-sm rounded-lg bg-white hvr-float-shadow con5">
                            <div class="con5">
                                <img class="w-100 image5" alt="Avatar" src="assets/image/img1.jpeg">
                                <div class="overlay5">
                                    <div class="text5">
                                        <div>
                                            <p class="mb-1 text-white"><i class="fas fa-user mr-2"></i>  Calvin Carlo</p>
                                            <p class="text-white"><i class="fas fa-user mr-2"></i>  13th August, 2019</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="card-body py-4">
                                <a class="text-decoration-none text-hvr1 text-body" href="#"><h5>Design your apps in your own way</h5></a>
                                <p class="mt-3">Start working with Landrick that can provide everything you need to generate awareness, drive traffic, connect.</p>
                                <div class="d-flex justify-content-between mt-4">
                                    <p class="mb-0 small">
                                        <a href="#" class="text-decoration-none text-grey2 text-hvr1"><i class="far fa-heart"></i> 33</a> 
                                        <a href="#" class="text-decoration-none ml-3 text-grey2 text-hvr1"><i class="far fa-comment-alt"></i> 08</a>
                                    </p>
                                    <p class="mb-0"><a href="#" class="text-decoration-none text-grey2 text-hvr1">Read More</a></p>
                                </div>
                            </div>
                        </div>
                    </div>
            
                    <div class="col-12 col-lg-4 mt-5">
                        <div class="shadow-sm rounded-lg bg-white hvr-float-shadow con5">
                            <div class="con5">
                                <img class="w-100 image5" alt="Avatar" src="assets/image/img2.jpeg">
                                <div class="overlay5">
                                    <div class="text5">
                                        <div>
                                            <p class="mb-1 text-white"><i class="fas fa-user mr-2"></i>  Calvin Carlo</p>
                                            <p class="text-white"><i class="fas fa-user mr-2"></i>  13th August, 2019</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="card-body py-4">
                                <a class="text-decoration-none text-hvr1 text-body mb-3" href="#"><h5>How apps is changing the IT world</h5></a>
                                <p class="mt-3">Start working with Landrick that can provide everything you need to generate awareness, drive traffic, connect.</p>
                                <div class="d-flex justify-content-between mt-4">
                                    <p class="mb-0 small">
                                        <a href="#" class="text-decoration-none text-grey2 text-hvr1"><i class="far fa-heart"></i> 33</a> 
                                        <a href="#" class="text-decoration-none ml-3 text-grey2 text-hvr1"><i class="far fa-comment-alt"></i> 08</a>
                                    </p>
                                    <p class="mb-0"><a href="#" class="text-decoration-none text-grey2 text-hvr1">Read More</a></p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-12 col-lg-4 mt-5">
                        <div class="shadow-sm rounded-lg bg-white hvr-float-shadow con5">
                            <div class="con5">
                                <img class="w-100 image5" alt="Avatar" src="assets/image/img3.jpeg">
                                <div class="overlay5">
                                    <div class="text5">
                                        <div>
                                            <p class="mb-1 text-white"><i class="fas fa-user mr-2"></i>  Calvin Carlo</p>
                                            <p class="text-white"><i class="fas fa-user mr-2"></i>  13th August, 2019</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="card-body py-4">
                                <a class="text-decoration-none text-hvr1 text-body mb-3" href="#"><h5>Smartest Applications for Business</h5></a>
                                <p class="mt-3">Start working with Landrick that can provide everything you need to generate awareness, drive traffic, connect.</p>
                                <div class="d-flex justify-content-between mt-4">
                                    <p class="mb-0 small">
                                        <a href="#" class="text-decoration-none text-grey2 text-hvr1"><i class="far fa-heart"></i> 33</a> 
                                        <a href="#" class="text-decoration-none ml-3 text-grey2 text-hvr1"><i class="far fa-comment-alt"></i> 08</a>
                                    </p>
                                    <p class="mb-0"><a href="#" class="text-decoration-none text-grey2 text-hvr1">Read More</a></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>


        <!-- Contents 22 -->
        <section class="bg-light py-5">
            <div class="container pb-5">
                <div class="row text-center">
                    <div class="col-md-8 mx-auto">
                        <h3>Join the happy faces around you</h3>
                        <p class="mt-3 col-md-8 mx-auto">Start working with <b class="text-blue">Landrick</b> that can provide everything you need to generate awareness, drive traffic, connect.</p>
                        <p class="h3 mt-5"><a href="#" class="btn btn px-4 py-2 btns9">Get Started Now</a> <a href="#" class="btn btn btns10 px-4 py-2 ml-3">Free Trial</a></p>
                    </div>
                </div>
            </div>
        </section>


        <!-- section3 -->
        <section class="section3 py-5">
            <div class="container py-4">
                <div class="row text-center">
                    <div class="col-md-6 mx-auto">
                        <h2>Our delighted users have a say</h2>
                        <p class="mt-3">Start working with <b class="text-blue">Landrick</b> that can provide everything you need to generate awareness, drive traffic, connect.</p>
                    </div>
                </div>
                <!-- Swiper -->
                <div class="swiper-container py-4 swiper4">
                    <div class="swiper-wrapper text-center">
                        <div class="swiper-slide">
                            <img class="rounded-circle mt-3 mb-3 col-3" src="assets/image/01.jpg">
                            <p class="mt-3">"Cheqd helps us in managing GST and other compliances. It also reminds about upcoming receivables. PF and ESI are also big pain for us and eagerly waiting for those to be available on Cheqd."</p>
                            <h5>Poulomi Chakraborty</h5>
                            <p class="text-blue">CEO, Custobridge</p>
                        </div>
                        <div class="swiper-slide">
                            <img class="rounded-circle mt-3 mb-3 col-3" src="assets/image/02.jpg">
                            <p class="mt-3">"Cheqd helps us in managing GST and other compliances. It also reminds about upcoming receivables. PF and ESI are also big pain for us and eagerly waiting for those to be available on Cheqd."</p>
                            <h5>Raja Bhowmick</h5>
                            <p class="text-blue">MD, BBC Constructions</p>
                        </div>
                        <div class="swiper-slide">
                            <img class="rounded-circle mt-3 mb-3 col-3" src="assets/image/03.jpg">
                            <p class="mt-3">"We deal in custom-designed premium furniture manufacturing and home interior design. Cheqd is a dependable partner for managing compliances with very little domain knowledge. Additionally, I can manage my employees and keep a track of financial health of my business."</p>
                            <h5>Deep Biswas</h5>
                            <p class="text-blue">Owner, Woodies</p>
                        </div>
                        <div class="swiper-slide">
                            <img class="rounded-circle mt-3 mb-3 col-3" src="assets/image/01.jpg">
                            <p class="mt-3">"Cheqd helps us in managing GST and other compliances. It also reminds about upcoming receivables. PF and ESI are also big pain for us and eagerly waiting for those to be available on Cheqd."</p>
                            <h5>Poulomi Chakraborty</h5>
                            <p class="text-blue">CEO, Custobridge</p>
                        </div>
                        <div class="swiper-slide">
                            <img class="rounded-circle mt-3 mb-3 col-3" src="assets/image/02.jpg">
                            <p class="mt-3">"Cheqd helps us in managing GST and other compliances. It also reminds about upcoming receivables. PF and ESI are also big pain for us and eagerly waiting for those to be available on Cheqd."</p>
                            <h5>Raja Bhowmick</h5>
                            <p class="text-blue">MD, BBC Constructions</p>
                        </div>
                        <div class="swiper-slide">
                            <img class="rounded-circle mt-3 mb-3 col-3" src="assets/image/03.jpg">
                            <p class="mt-3">"We deal in custom-designed premium furniture manufacturing and home interior design. Cheqd is a dependable partner for managing compliances with very little domain knowledge. Additionally, I can manage my employees and keep a track of financial health of my business."</p>
                            <h5>Deep Biswas</h5>
                            <p class="text-blue">Owner, Woodies</p>
                        </div>
                    </div><br><br>
                    <div class="swiper-pagination text-center pr-3 pb-3">
                        <div class="swiper-pagination wdt bg-white p-3 txt2 text-center mb-0"></div>
                    </div>
                </div>
            </div>
        </section>
        

        <!-- footer -->
        <footer>
            <?php include("footer.php"); ?>
        </footer>
    </main>

<!-- bootstrap 4.4.1 -->
<script src="assets/bootstrap-4.4.1/js/jquery-3.4.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="assets/bootstrap-4.4.1/js/bootstrap.min.js"></script>
<!-- page-scrollreveal-3.3.2 -->
<script src="assets/page-scrollreveal-3.3.2/scrollreveal.min.js"></script>
<!-- poppup video -->
<script src="assets/poppup-video-jquary-3.2.1/grt-youtube-popup.min.js"></script>
<!-- typed-master -->
<!-- <script src="assets/typed.js-master/assets/demos.js"></script> -->
<script src="assets/typed.js-master/lib/typed.js"></script>
<!-- swipre-master -->
<script src="assets/swiper-master/package/js/swiper.min.js"></script>

<!-- javascript.js --> 
<script src="assets/js/common.js"></script>          
<script src="assets/js/index.js"></script>
<script src="assets/js/mobile-apps.js"></script>

<script>
    //poppup video    
    $(".youtube-link").grtyoutube({
        autoPlay:true,
        theme: "dark"
    });
</script>
    
</body>
</html>