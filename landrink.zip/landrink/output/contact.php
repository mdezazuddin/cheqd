<?php $page= "contact";?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name=”description”>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<title>xyz</title>

<!-- normalize -->
<link rel="stylesheet" href="assets/css/normalize.min.css">
<!-- fav-icon -->    
<link rel="shortcut icon" href="assets/image/brand1.png"> 
<!-- Bootstrap 4.4.1-->
<link rel="stylesheet" href="assets/bootstrap-4.4.1/css/bootstrap.min.css">
<!-- Font-Awesome-5 -->
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
<!-- google-fonts -->    
<link href="https://fonts.googleapis.com/css2?family=Nunito:ital,wght@0,200;0,300;0,400;0,600;0,700;0,800;0,900;1,200;1,300;1,400;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
<!-- hover-master -->
<link rel="stylesheet" href="assets/Hover-master/css/hover.css">
<!-- style.css -->
<link rel="stylesheet" href="assets/css/style.css">

</head>
<body>
    <main>
        <!-- header -->
        <header>
            <?php include("header.php"); ?>
        </header>


        <!-- section1 -->
        <section class="section1 bg-light">
            <div class="container pt-md-5 pb-md-5">
                <div class="row pt-5 pb-5">
                    <div class="col-lg-12 pt-5 pb-5 text-center">
                        <h1 class="text-body font-weight-bold h5">CONTACT US</h1>
                    </div>
                </div>
            </div>
        </section>


        <!-- Feature 9 -->
        <section class="pb-5">
            <div class="container">
                <div class="row mt-4 text-center">
                    <div class="col-12 mb-5">
                        <ul class="pagination justify-content-center border border-muted p-1 bg-white col-md-5 mx-auto mtt7">
                            <li class="page-item"><a class="page-link border-0 font-weight-bold small text-black1 text-hvr1" href="javascript:void(0);">LANDRICK <i class="fa fa-chevron-right ml-2 fntt2"></i></a></li>
                            <li class="page-item"><a class="page-link border-0 font-weight-bold small text-black1 text-hvr1" href="javascript:void(0);">PAGE <i class="fa fa-chevron-right ml-md-2 fntt2"></i></a></li>
                            <li class="page-item"><a class="page-link border-0 font-weight-bold small text-black1 text-hvr1" href="javascript:void(0);">CONTACT <i class="fa fa-chevron-right ml-md-2 fntt2"></i></a></li>
                            <li class="page-item"><a class="page-link border-0 font-weight-bold small text-blue" href="javascript:void(0);">CONTACT ONE </a></li>
                          </ul>
                    </div>

                    <div class="col-12 col-lg-4 col-md-6 mt-4 parent2">
                        <div class="parent2 mttl1">
                            <div class="child2 anim-des mttl3"><span class="p-5"></span></div>
                            <div class="layers2">
                                <img alt="image" class="w-25 fntts7 mt-4" src="assets/image/bitcoin.svg">
                            </div>
                        </div>
                        <h5><b>Phone</b></h5>
                        <p class="mt-3">Start working with Landrick that can provide everything</p>
                        <a class="text-decoration-none text-blue" href="tel:+152 534-468-854">+152 534-468-854</a>
                    </div>
            
                    <div class="col-12 col-lg-4 col-md-6 mt-4 parent2">
                        <div class="parent2 mttl1">
                            <div class="child2 anim-des mttl3"><span class="p-5"></span></div>
                            <div class="layers2">
                                <img alt="image" class="w-25 fntts7 mt-4" src="assets/image/Email.svg">
                            </div>
                        </div>
                        <h5><b>Email</b></h5>
                        <p class="mt-3">Start working with Landrick that can provide everything</p>
                        <a class="text-decoration-none text-blue" href="mailto:contact@example.com">contact@example.com</a>
                    </div>
            
                    <div class="col-12 col-lg-4 col-md-6 mt-4 parent2">
                        <div class="parent2 mttl1">
                            <div class="child2 anim-des mttl3"><span class="p-5"></span></div>
                            <div class="layers2">
                                <img alt="image" class="w-25 fntts7 mt-4" src="assets/image/location.svg">
                            </div>
                        </div>
                        <h5><b>Location</b></h5>
                        <p class="mt-3">C/54 Northwest Freeway, Suite 558,
                            Houston, USA 485</p>
                        <a class="text-decoration-none text-blue" href="#">View on Google map</a>    
                    </div>
                </div>
            </div>
        </section>


        <!-- section2 -->
        <section class="section2 pb-5">
            <div class="container pb-5">
                <div class="row">
                    <div class="col-12 mt-5 col-lg-5">
                        <div class="shadow-sm rounded-lg card-body p-4 py-5">
                            <form name="frmContact" id="frmContact" method="post" action="#" enctype="multipart/form-data">
                                <h5><b>Get In Touch !</b></h5>
                                <div class="row">
                                    <div class="form-group col-md-6 mt-2">
                                        <label class="small text-dark" for=""><b>Your Name</b> <span class="text-danger">*</span></label>
                                        <div class="border border-muted rounded d-flex p-1 pl-3">
                                            <i class="fa fa-user mt-2"></i>
                                            <input type="text" placeholder="First Name:" name="txtName" id="txtName" class="form-control border-0 shadow-none p1">
                                        </div>
                                    </div>
                                    <div class="form-group col-md-6 mt-2">
                                        <label class="small text-dark" for=""><b>Your Email</b> <span class="text-danger">*</span></label>
                                        <div class="border border-muted rounded d-flex p-1 pl-3">
                                            <i class="fa fa-envelope mt-2 pt-1"></i>
                                            <input type="email" placeholder="your email:" name="txtName" id="txtName" class="form-control border-0 shadow-none p1">
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group mt-2">
                                    <label class="small text-dark" for=""><b>Subject</b> <span class="text-danger">*</span></label>
                                    <div class="border border-muted rounded d-flex p-1 pl-3">
                                        <i class="fa fa-user mt-2"></i>
                                        <input type="text" placeholder="Subject" name="txtName" id="txtName" class="form-control border-0 shadow-none p1">
                                    </div>
                                </div>
                                <div class="form-group mt-2">
                                    <label class="small text-dark" for=""><b>Comments</b> <span class="text-danger">*</span></label>
                                    <div class="border border-muted rounded d-flex p-1 pl-3">
                                        <i class="fa fa-comment mt-2"></i>
                                        <textarea name="txtMessage" class="form-control border-0 shadow-none p1" rows="5" placeholder="Your Message"></textarea>
                                    </div>
                                </div>
                                <div class="form-group mt-4">
                                    <a href="#" class="btn btn btns9 w-100 py-2 rounded"><b>Send Message</b></a>
                                </div>
                            </form>
                        </div>
                    </div>
                    <!-- google-map -->
                    <div class="col-12 col-lg-7 mt-5">
                        <img class="w-100 mt-5" src="assets/image/contact.png">
                    </div>
                </div>
            </div>
        </section>


        <!-- section2 -->
        <section class="section2">
            <div class="container-fluid">
                <div class="row">
                    <!-- google-map -->
                    <div class="col-12 pl-0 pr-0">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3024.0721376413476!2d-73.73979336718509!3d40.7164284386799!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c263d234963e1f%3A0xb8c246c12c49cdc6!2s217-44%2098th%20Ave%2C%20Queens%20Village%2C%20NY%2011429%2C%20USA!5e0!3m2!1sen!2sin!4v1583386875157!5m2!1sen!2sin"
        width="100%" height="540px" frameborder="0" style="margin: 0;" allowfullscreen=""></iframe>
                    </div>
                </div>
            </div>
        </section>

    
        <!-- footer -->
        <footer>
            <?php include("footer.php"); ?>
        </footer>
    </main>


<!-- bootstrap 4.4.1 -->
<script src="assets/bootstrap-4.4.1/js/jquery-3.4.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="assets/bootstrap-4.4.1/js/bootstrap.min.js"></script>
<!-- page-scrollreveal-3.3.2 -->
<script src="assets/page-scrollreveal-3.3.2/scrollreveal.min.js"></script>

<!-- javascript.js --> 
<script src="assets/js/common.js"></script>           

</body>
</html>