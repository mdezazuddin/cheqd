<?php $page= "service";?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name=”description”>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<title>xyz</title>

<!-- normalize -->
<link rel="stylesheet" href="assets/css/normalize.min.css">
<!-- fav-icon -->    
<link rel="shortcut icon" href="assets/image/brand1.png"> 
<!-- Bootstrap 4.4.1-->
<link rel="stylesheet" href="assets/bootstrap-4.4.1/css/bootstrap.min.css">
<!-- Font-Awesome-5 -->
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
<!-- google-fonts -->    
<link href="https://fonts.googleapis.com/css2?family=Nunito:ital,wght@0,200;0,300;0,400;0,600;0,700;0,800;0,900;1,200;1,300;1,400;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
<!-- hover-master -->
<link rel="stylesheet" href="assets/Hover-master/css/hover.css">
<!-- swipre-master -->
<link rel="stylesheet" href="assets/swiper-master/package/css/swiper.css">
<!-- poppup video -->
<link rel="stylesheet" href="assets/poppup-video-jquary-3.2.1/grt-youtube-popup.min.css">
<!-- style.css -->
<link rel="stylesheet" href="assets/css/style.css">

</head>
<body>
    <main>
        <!-- header -->
        <header>
            <?php include("header.php"); ?>
        </header>

        
        <!-- Contents 14 -->
        <section class="py-md-5 mb-5">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-12 col-lg-7 ml-md-auto text-left">
                        <h1 class="mt-4">Build Anything
                            For Your Project</h1>
                        <p class="mt-3 p2">Launch your campaign and benefit from our expertise on designing and managing conversion centered bootstrap4 html page.</p>
                        <p class="h3 mt-4 pt-2">
                            <a href="#" class="btn btn px-4 py-2 btns9">Our Service</a> 
                            <a class="text-decoration-none text-body youtube-link" href="#" youtubeid="qLCLvzTGFVM" class="ml-3"><span class="fa-stack fa-xs mt-1">
                                <i class="fa fa-circle fa-stack-2x text-blue"></i>
                                <i class="fa fa-play fa-stack-1x text-white mr-3 fntt2 pl-1"></i>
                            </span> <span class="fntt1">WATCH VIDEO</span></a>
                        </p>
                    </div>
                    <div class="col-12 col-lg-5 mt-4 text-md-right">
                        <img class="w-100" src="assets/image/services.svg">
                    </div>
                </div>
            </div>
        </section>


        <!-- Feature 9 -->
        <section class="pb-5">
            <div class="container">
                <div class="row mt-4 text-center">
                    <div class="col-12 col-lg-4 col-md-6 mt-4 parent2">
                        <div class="parent2 mttl1">
                            <div class="child2 anim-des mttl3"><span class="p-5"></span></div>
                            <div class="layers2">
                                <img alt="image" class="w-25 fntts7 mt-4" src="assets/image/device.svg">
                            </div>
                        </div>
                        <h5>Built for Everyone</h5>
                        <p class="mt-3">Nisi aenean vulputate eleifend tellus vitae eleifend enim a Aliquam eleifend aenean elementum semper.</p>
                    </div>
            
                    <div class="col-12 col-lg-4 col-md-6 mt-4 parent2">
                        <div class="parent2 mttl1">
                            <div class="child2 anim-des mttl3"><span class="p-5"></span></div>
                            <div class="layers2">
                                <img alt="image" class="w-25 fntts7 mt-4" src="assets/image/device.svg">
                            </div>
                        </div>
                        <h5>Responsive Design</h5>
                        <p class="mt-3">Allegedly, a Latin scholar established the origin of the established text by compiling unusual word.</p>
                    </div>
            
                    <div class="col-12 col-lg-4 col-md-6 mt-4 parent2">
                        <div class="parent2 mttl1">
                            <div class="child2 anim-des mttl3"><span class="p-5"></span></div>
                            <div class="layers2">
                                <img alt="image" class="w-25 fntts7 mt-4" src="assets/image/code.svg">
                            </div>
                        </div>
                        <h5>Build Everything</h5>
                        <p class="mt-3">It seems that only fragments of the original text remain in only fragments the Lorem Ipsum texts used today.</p>
                    </div>
                </div>
            </div>
        </section>


        <!-- Feature 9 -->
        <section class="bg-light py-5">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-12 col-md-6 pl-md-5 mt-5">
                        <h2>Get Notified About Importent Email</h2>
                        <p class="mt-4">This prevents repetitive patterns from impairing the overall visual impression and facilitates the comparison of different typefaces. Furthermore, it is advantageous when the dummy text is relatively realistic.</p>
                        <p>
                            <a class="btn btn btns10 rounded-lg px-4 py-2 mt-4" href="#"> Start Now <span class="fa fa-chevron-right fntt2 ml-2"></span></a>
                        </p>
                    </div>
                    <div class="col-12 col-md-6 pl-md-5 mt-5">
                        <img class="w-100" src="assets/image/laptop.png">
                    </div>
                </div>
            </div>
        </section>


        <!-- Feature 9 -->
        <section class="bg-light pb-5">
            <div class="container pt-5 pb-5">
                <div class="row mt-4 tex-md-left text-center">
                    <div class="col-12 col-lg-4 col-md-6 mt-4">
                        <h2 class="display-4 text-blue mt-3 count-this" data-text="%">97</h2>
                        <h5>Happy Client</h5>
                        <p class="mt-3">The most well-known dummy text is the 'Lorem Ipsum', which is said to have originated in the 16th century.</p>
                    </div>
                    <div class="col-12 col-lg-4 col-md-6 mt-4">
                        <h2 class="display-4 text-blue mt-3 count-this" data-text="+">15</h2>
                        <h5>Awards</h5> 
                        <p class="mt-3">The most well-known dummy text is the 'Lorem Ipsum', which is said to have originated in the 16th century.</p>
                    </div>
                    <div class="col-12 col-lg-4 col-md-6 mt-4">
                        <h2 class="display-4 text-blue mt-3 count-this" data-text="%">98</h2>
                        <h5>Project Complete</h5>
                        <p class="mt-3">The most well-known dummy text is the 'Lorem Ipsum', which is said to have originated in the 16th century.</p>
                    </div>
                </div>
            </div>
        </section>


        <!-- Feature 9 -->
        <section class="py-5">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-12 col-md-6 mt-5">
                        <img class="w-100" src="assets/image/analyze_report_4.svg">
                    </div>
                    <div class="col-12 col-md-6 pl-md-5 mt-5">
                        <h2>Clean And Modern Code</h2>
                        <p class="mt-4">This prevents repetitive patterns from impairing the overall visual impression and facilitates the comparison of different typefaces. Furthermore, it is advantageous when the dummy text is relatively realistic.</p>
                        <p>
                            <a class="btn btn btns10 rounded-lg px-4 py-2 mt-4" href="#"> Start Now <span class="fa fa-chevron-right fntt2 ml-2"></span></a>
                        </p>
                    </div>
                </div>
            </div>
        </section>


        <!-- Feature 9 -->
        <section class="py-5">
            <div class="container">
                <div class="row text-center">
                    <div class="col-md-6 mx-auto">
                        <h2>Our Happy Customers</h2>
                        <p class="mt-3">Start working with <b class="text-blue">Landrick</b> that can provide everything you need to generate awareness, drive traffic, connect.</p>
                    </div>
                </div>
                <div class="row align-items-center">
                    <div class="col-12 mt-5">
                        <!-- Swiper -->
                        <div class="swiper-container pr-4 swiper4">
                            <div class="swiper-wrapper px-3 text-center">
                                <div class="swiper-slide">
                                    <div class="card p-3">
                                        <img class="rounded-circle mx-auto mt-3 mb-3 col-4" src="assets/image/amazon.svg">
                                        <p class="mt-3">"that can provide everything you need to generate awareness, drive traffic, connect."</p>
                                        <p class="text-blue">-Christa Smith-</p>
                                    </div>
                                </div>
                                <div class="swiper-slide">
                                    <div class="card p-3">
                                        <img class="rounded-circle mx-auto mt-3 mb-3 col-4" src="assets/image/google.svg">
                                        <p class="mt-3">"that can provide everything you need to generate awareness, drive traffic, connect."</p>
                                        <p class="text-blue">-Christa Smith-</p>
                                    </div>
                                </div>
                                <div class="swiper-slide">
                                    <div class="card p-3">
                                        <img class="rounded-circle mx-auto mt-3 mb-3 col-4" src="assets/image/lenovo.svg">
                                        <p class="mt-3">"that can provide everything you need to generate awareness, drive traffic, connect."</p>
                                        <p class="text-blue">-Christa Smith-</p>
                                    </div>
                                </div>
                                <div class="swiper-slide">
                                    <div class="card p-3">
                                        <img class="rounded-circle mx-auto mt-3 mb-3 col-4" src="assets/image/paypal.svg">
                                        <p class="mt-3">"that can provide everything you need to generate awareness, drive traffic, connect."</p>
                                        <p class="text-blue">-Christa Smith-</p>
                                    </div>
                                </div>
                                <div class="swiper-slide">
                                    <div class="card p-3">
                                        <img class="rounded-circle mx-auto mt-3 mb-3 col-4" src="assets/image/shopify.svg">
                                        <p class="mt-3">"that can provide everything you need to generate awareness, drive traffic, connect."</p>
                                        <p class="text-blue">-Christa Smith-</p>
                                    </div>
                                </div>
                                <div class="swiper-slide">
                                    <div class="card p-3">
                                        <img class="rounded-circle mx-auto mt-3 mb-3 col-4" src="assets/image/spotify.svg">
                                        <p class="mt-3">"that can provide everything you need to generate awareness, drive traffic, connect."</p>
                                        <p class="text-blue">-Christa Smith-</p>
                                    </div>
                                </div>
                            </div><br><br><br>
                            <div class="swiper-pagination text-center pr-3 pb-3">
                                <div class="swiper-pagination wdt bg-white p-3 txt2 text-center mb-0"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>


        <!-- Contents 22 -->
        <section class="py-5">
            <div class="container pb-5">
                <div class="row text-center">
                    <div class="col-md-8 mx-auto">
                        <h3>Subscribe for our Latest Newsletter</h3>
                        <p class="mt-4 col-md-9 mx-auto">Start working with <b class="text-blue">Landrick</b> that can provide everything you need to generate awareness, drive traffic, connect.</p>
                        <p class="mt-4 pt-2">
                            <form class="d-flex justify-content-center rounded-lg">
                                <div class="mt-3 col-md-10 pr-0">
                                    <input class="form-control form-control-lg input1 pt-1 w-100 shadow-none" type="text" name="name" placeholder="Your Email :">
                                </div>
                                <span><button class="btn btn btns9 py-2 p2 input2 rounded-left-0 px-4 mt-3" type="button"><small class="font-weight-bold">Subscribe</small></button></span>
                            </form>
                        </p>
                    </div>
                </div>
            </div>
        </section>
        

        <!-- footer -->
        <footer>
            <?php include("footer.php"); ?>
        </footer>
    </main>

<!-- bootstrap 4.4.1 -->
<script src="assets/bootstrap-4.4.1/js/jquery-3.4.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="assets/bootstrap-4.4.1/js/bootstrap.min.js"></script>
<!-- page-scrollreveal-3.3.2 -->
<script src="assets/page-scrollreveal-3.3.2/scrollreveal.min.js"></script>
<!-- swipre-master -->
<script src="assets/swiper-master/package/js/swiper.min.js"></script>
<!-- poppup video -->
<script src="assets/poppup-video-jquary-3.2.1/grt-youtube-popup.min.js"></script>

<!-- javascript.js --> 
<script src="assets/js/common.js"></script>          
<script src="assets/js/service.js"></script>
    
<script>
    //poppup video    
    $(".youtube-link").grtyoutube({
        autoPlay:true,
        theme: "dark"
    });
</script>

</body>
</html>