<?php $page= "mobile-apps";?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name=”description”>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<title>xyz</title>

<!-- normalize -->
<link rel="stylesheet" href="assets/css/normalize.min.css">
<!-- fav-icon -->    
<link rel="shortcut icon" href="assets/image/brand1.png"> 
<!-- Bootstrap 4.4.1-->
<link rel="stylesheet" href="assets/bootstrap-4.4.1/css/bootstrap.min.css">
<!-- Font-Awesome-5 -->
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
<!-- google-fonts -->    
<link href="https://fonts.googleapis.com/css2?family=Nunito:ital,wght@0,200;0,300;0,400;0,600;0,700;0,800;0,900;1,200;1,300;1,400;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
<!-- hover-master -->
<link rel="stylesheet" href="assets/Hover-master/css/hover.css">
<!-- swipre-master -->
<link rel="stylesheet" href="assets/swiper-master/package/css/swiper.css">
<!-- style.css -->
<link rel="stylesheet" href="assets/css/style.css">

</head>
<body>
    <main>
        <!-- header -->
        <header>
            <?php include("header.php"); ?>
        </header>

        
        <!-- Contents 14 -->
        <section class="py-md-5 mb-5 mt-md-5">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-12 col-lg-6 mt-4 ml-md-auto text-left">
                        <h1 class="mt-4 font-weight-bold">Manage all of you stuff using <span class="text-blue">Landrick</span> app</h1>
                        <p class="mt-3 p2">Launch your campaign and benefit from our expertise on designing and managing conversion centered bootstrap4 html page.</p>
                        <p>
                            <a class="btn btn btns9 px-4 py-2 mt-4" href="#"><small><i class="fab fa-apple mr-2"></i></small> App Store</a>
                            <a class="btn btn btns10 px-4 py-2 ml-2 mt-4" href="#"><small><i class="fab fa-google-play mr-2"></i></small> Play Store</a> 
                        </p>
                    </div>
                    <div class="col-12 col-lg-6 mt-4 text-md-right">
                        <img alt="image" class="img-fluid" src="assets/image/home.png">
                    </div>
                </div>
            </div>
        </section>


        <!-- Feature 9 -->
        <section class="bg-light py-5">
            <div class="container py-5">
                <div class="row text-center">
                    <div class="col-md-6 mx-auto">
                        <h2>App Features</h2>
                        <p class="mt-3">Start working with <b class="text-blue">Landrick</b> that can provide everything you need to generate awareness, drive traffic, connect.</p>
                    </div>
                </div>
                
                <div class="row align-items-center">
                    <div class="col-12 col-md-8 mt-4">
                        <div class="row text-md-left">
                            <div class="col-12 col-md-6 mt-5">
                                <div class="row">
                                    <div class="col-md-2">
                                        <span class="fa-stack fa-lg mt-2">
                                            <i class="fa fa-circle fa-stack-2x text-grey3"></i>
                                            <i class="fas fa-desktop fa-stack-1x text-blue fntt1"></i>
                                        </span>
                                    </div>
                                    <div class="col-md-10 pl-md-4">
                                        <h5>Use On Any Device</h5>
                                        <p class="mt-2">Composed in a pseudo-Latin language which more or less pseudo-Latin language corresponds.</p>
                                    </div>
                                </div>
                            </div>
                      
                            <div class="col-12 col-md-6 mt-5">
                                <div class="row">
                                    <div class="col-md-2">
                                        <span class="fa-stack fa-lg mt-2">
                                            <i class="fa fa-circle fa-stack-2x text-grey3"></i>
                                            <i class="fa fa-user fa-stack-1x text-blue fntt1"></i>
                                        </span>
                                    </div>
                                    <div class="col-md-10 pl-md-4">
                                        <h5>Feather Icons</h5>
                                        <p class="mt-2">Composed in a pseudo-Latin language which more or less pseudo-Latin language corresponds.</p>
                                    </div>
                                </div>
                            </div>

                            <div class="col-12 col-md-6 mt-5">
                                <div class="row">
                                    <div class="col-md-2">
                                        <span class="fa-stack fa-lg mt-2">
                                            <i class="fa fa-circle fa-stack-2x text-grey3"></i>
                                            <i class="far fa-eye fa-stack-1x text-blue fntt1"></i>
                                        </span>
                                    </div>
                                    <div class="col-md-10 pl-md-4">
                                        <h5>Retina Ready</h5>
                                        <p class="mt-2">Composed in a pseudo-Latin language which more or less pseudo-Latin language corresponds.</p>
                                    </div>
                                </div>
                            </div>

                            <div class="col-12 col-md-6 mt-5">
                                <div class="row">
                                    <div class="col-md-2">
                                        <span class="fa-stack fa-lg mt-2">
                                            <i class="fa fa-circle fa-stack-2x text-grey3"></i>
                                            <i class="far fa-user fa-stack-1x text-blue fntt1"></i>
                                        </span>
                                    </div>
                                    <div class="col-md-10 pl-md-4">
                                        <h5>W3c Valid Code</h5>
                                        <p class="mt-2">Composed in a pseudo-Latin language which more or less pseudo-Latin language corresponds.</p>
                                    </div>
                                </div>
                            </div>

                            <div class="col-12 col-md-6 mt-5">
                                <div class="row">
                                    <div class="col-md-2">
                                        <span class="fa-stack fa-lg mt-2">
                                            <i class="fa fa-circle fa-stack-2x text-grey3"></i>
                                            <i class="fas fa-mobile-alt fa-stack-1x text-blue fntt1"></i>
                                        </span>
                                    </div>
                                    <div class="col-md-10 pl-md-4">
                                        <h5>Fully Responsive</h5>
                                        <p class="mt-2">Composed in a pseudo-Latin language which more or less pseudo-Latin language corresponds.</p>
                                    </div>
                                </div>
                            </div>

                            <div class="col-12 col-md-6 mt-5">
                                <div class="row">
                                    <div class="col-md-2">
                                        <span class="fa-stack fa-lg mt-2">
                                            <i class="fa fa-circle fa-stack-2x text-grey3"></i>
                                            <i class="far fa-heart fa-stack-1x text-blue fntt1"></i>
                                        </span>
                                    </div>
                                    <div class="col-md-10 pl-md-4">
                                        <h5>Browser Compatibility</h5>
                                        <p class="mt-2">Composed in a pseudo-Latin language which more or less pseudo-Latin language corresponds.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-md-4 mt-5">
                        <img class="mx-auto d-block" src="assets/image/feature.png">
                    </div>
                </div>
            </div>
        </section>


        <!-- Feature 9 -->
        <section class="bg-light py-5">
            <div class="container">
                <div class="row text-center">
                    <div class="col-md-6 mx-auto">
                        <h2>How Can We Help You ?</h2>
                        <p class="mt-3">Start working with <b class="text-blue">Landrick</b> that can provide everything you need to generate awareness, drive traffic, connect.</p>
                    </div>
                </div>
                
                <div class="row align-items-center">
                    <div class="col-12 col-md-5 mt-5">
                        <img class="w-100" src="assets/image/home.png">
                    </div>
                    <div class="col-12 col-md-7 pl-md-5 mt-5">
                        <h2>Best <span class="text-blue">Landrick</span> App Partner For Your Life</h2>
                        <p class="mt-4">Start working with <a class="text-blue" href="#">Landrick</a> that can provide everything you need to generate awareness, drive traffic, connect.</p>
                        <div class="mt-4">
                            <p class="mb-1"><i class="far fa-check-circle mr-3 text-success"></i><span>Digital Marketing Solutions for Tomorrow</span></p>
                            <p class="mb-1"><i class="far fa-check-circle mr-3 text-success"></i><span>Our Talented & Experienced Marketing Agency</span></p>
                            <p class="mb-1"><i class="far fa-check-circle mr-3 text-success"></i><span>Create your own skin to match your brand</span></p>
                        </div>
                        <p class="mt-3"><a class="text-blue" href="#">Find Out More <i class=" fa fa-chevron-right ml-2 fntt2"></i></a></p>
                    </div>
                </div>
            </div>
        </section>


        <!-- Call to Action 13 -->
        <section class="bg-light pb-5">
            <div class="container py-5">
                <div class="row text-center">
                    <div class="col-md-6 mx-auto">
                        <h2><span class="text-blue">Landrick</span> App Showcase</h2>
                        <p class="mt-3">Start working with <b class="text-blue">Landrick</b> that can provide everything you need to generate awareness, drive traffic, connect.</p>
                    </div>
                </div>
                <div class="row mt-5">
                    <div class="col-12">
                        <!-- Nav pills -->
                        <ul class="nav nav-pills justify-content-center" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link active px-5 py-2 h5 font-weight-normal text-black1" data-toggle="pill" href="#home">High Performance</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link px-5 py-2 h5 font-weight-normal text-black1" data-toggle="pill" href="#menu1">Creative Design</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link px-5 py-2 h5 font-weight-normal text-black1" data-toggle="pill" href="#menu2">24 / 7 Support</a>
                            </li>
                        </ul>

                        <!-- Tab panes -->
                        <div class="tab-content">
                            <div id="home" class="container tab-pane active"><br>
                                <div class="row align-items-center">
                                    <div class="col-12 col-md-6 mt-5">
                                        <img class="w-100" src="assets/image/2.png">
                                    </div>
                                    <div class="col-12 text-left col-md-6 pl-md-5 mt-5">
                                        <h2 class="text-body"><small><i class="fa fa-angle-double-right text-blue mr-2"></i></small>High Performing Landing App</h2>
                                        <p class="mt-4">Start working with <a class="text-blue" href="#">Landrick</a> that can provide everything you need to generate awareness, drive traffic, connect.</p>
                                        <div class="mt-4">
                                            <p class="mb-1"><i class="far fa-check-circle mr-3 text-success"></i><span>Digital Marketing Solutions for Tomorrow</span></p>
                                            <p class="mb-1"><i class="far fa-check-circle mr-3 text-success"></i><span>Our Talented & Experienced Marketing Agency</span></p>
                                            <p class="mb-1"><i class="far fa-check-circle mr-3 text-success"></i><span>Create your own skin to match your brand</span></p>
                                        </div>
                                        <p class="mt-3"><a class="text-blue" href="#">Find Out More <i class=" fa fa-chevron-right ml-2 fntt2"></i></a></p>
                                    </div>
                                </div>
                            </div>
                            <div id="menu1" class="container tab-pane fade"><br>
                                <div class="row align-items-center">
                                    <div class="col-12 col-md-6 mt-5">
                                        <img class="w-100" src="assets/image/3.png">
                                    </div>
                                    <div class="col-12 text-left col-md-6 pl-md-5 mt-5">
                                        <h2 class="text-body"><small><i class="fa fa-angle-double-right text-blue mr-2"></i></small>Creative Design and Clean Code</h2>
                                        <p class="mt-4">Start working with <a class="text-blue" href="#">Landrick</a> that can provide everything you need to generate awareness, drive traffic, connect.</p>
                                        <div class="mt-4">
                                            <p class="mb-1"><i class="far fa-check-circle mr-3 text-success"></i><span>Digital Marketing Solutions for Tomorrow</span></p>
                                            <p class="mb-1"><i class="far fa-check-circle mr-3 text-success"></i><span>Our Talented & Experienced Marketing Agency</span></p>
                                            <p class="mb-1"><i class="far fa-check-circle mr-3 text-success"></i><span>Create your own skin to match your brand</span></p>
                                        </div>
                                        <p class="mt-3"><a class="text-blue" href="#">Find Out More <i class=" fa fa-chevron-right ml-2 fntt2"></i></a></p>
                                    </div>
                                </div>
                            </div>
                            <div id="menu2" class="container tab-pane fade"><br>
                                <div class="row align-items-center">
                                    <div class="col-12 col-md-6 mt-5">
                                        <img class="w-100" src="assets/image/4.png">
                                    </div>
                                    <div class="col-12 text-left col-md-6 pl-md-5 mt-5">
                                        <h2 class="text-body"><small><i class="fa fa-angle-double-right text-blue mr-2"></i></small>24 / 7 App Supports and Responsive</h2>
                                        <p class="mt-4">Start working with <a class="text-blue" href="#">Landrick</a> that can provide everything you need to generate awareness, drive traffic, connect.</p>
                                        <div class="mt-4">
                                            <p class="mb-1"><i class="far fa-check-circle mr-3 text-success"></i><span>Digital Marketing Solutions for Tomorrow</span></p>
                                            <p class="mb-1"><i class="far fa-check-circle mr-3 text-success"></i><span>Our Talented & Experienced Marketing Agency</span></p>
                                            <p class="mb-1"><i class="far fa-check-circle mr-3 text-success"></i><span>Create your own skin to match your brand</span></p>
                                        </div>
                                        <p class="mt-3"><a class="text-blue" href="#">Find Out More <i class=" fa fa-chevron-right ml-2 fntt2"></i></a></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>


        <!-- Pricings 5 -->
        <section class="py-5">
            <div class="container py-5">
                <div class="row text-center">
                    <div class="col-md-6 mx-auto">
                        <h2>Choose The Pricing Plan</h2>
                        <p class="mt-3">Start working with <b class="text-blue">Landrick</b> that can provide everything you need to generate awareness, drive traffic, connect.</p>
                    </div>
                </div>
        
                <div class="row mt-5 align-items-center">
                    <div class="col-12 col-sm-10 col-md-8 p-3 m-auto col-lg-4 text-center">
                        <div class="bg-light pb-5 pt-5 pl-4 pr-4 rounded-right hvr-grow w-100 card7">
                            <h6 class="font-weight-bold clr2">FREE</h6>
                            <p class="mt-4 mb-5 text-body"><strong><sup class="h5 text-body">$</sup></strong> <strong><sub class="h1">0</sub></strong> <strong><sub class="h4 text-body">/mo</sub></strong></p>
                            <div>
                                <p class="mb-1"><i class="fa fa-check mr-3 text-success"></i><span>Full Access</span></p>
                                <p class="mb-1"><i class="fa fa-check mr-3 text-success"></i><span>Enhanced Security</span></p>
                                <p class="mb-1"><i class="fa fa-check mr-3 text-success"></i><span>Source Files</span></p>
                                <p class="mb-1"><i class="fa fa-check mr-3 text-success"></i><span>1 Domain Free</span></p>
                            </div>
                            <p class="text-center pt-4"><a href="https://www.froala.com" class="btn btn btns9 px-4 py-2 rounded-lg mt-4">Buy Now</a></p>
                        </div>
                    </div>
            
                    <div class="col-12 col-sm-10 col-md-8 ml-auto mr-auto col-lg-4 text-center mt-4 mt-lg-0 sl-1 pt-0 pt-lg-3 pb-0 pb-lg-3 fdb-touch rounded bg-light hvr-grow w-100">
                        <div class="bg-light pb-5 pt-5 pl-4 pr-4 rounded-right card7">
                            <h6 class="font-weight-bold text-blue clr2">STARTER</h6>
                            <p class="mt-4 mb-5 text-body"><strong><sup class="h5 text-body">$</sup></strong> <strong><sub class="h1">39</sub></strong> <strong><sub class="h4 text-body">/mo</sub></strong></p>
                            <div>
                                <p class="mb-1"><i class="fa fa-check mr-3 text-success"></i><span>Full Access</span></p>
                                <p class="mb-1"><i class="fa fa-check mr-3 text-success"></i><span>Enhanced Security</span></p>
                                <p class="mb-1"><i class="fa fa-check mr-3 text-success"></i><span>Source Files</span></p>
                                <p class="mb-1"><i class="fa fa-check mr-3 text-success"></i><span>1 Domain Free</span></p>
                            </div>
                            <p class="text-center pt-4"><a href="https://www.froala.com" class="btn btn btns9 px-4 py-2 rounded-lg mt-4">Get Started</a></p>
                        </div>
                    </div>
            
                    <div class="col-12 col-sm-10 col-md-8 m-auto col-lg-4 text-center">
                        <div class="bg-light pb-5 pt-5 pl-4 pr-4 rounded-right hvr-grow w-100 card7">
                            <h6 class="font-weight-bold clr2">PROFESSIONAL</h6>
                            <p class="mt-4 mb-5 text-body"><strong><sup class="h5 text-body">$</sup></strong> <strong><sub class="h1">59</sub></strong> <strong><sub class="h4 text-body">/mo</sub></strong></p>
                            <div>
                                <p class="mb-1"><i class="fa fa-check mr-3 text-success"></i><span>Full Access</span></p>
                                <p class="mb-1"><i class="fa fa-check mr-3 text-success"></i><span>Enhanced Security</span></p>
                                <p class="mb-1"><i class="fa fa-check mr-3 text-success"></i><span>Source Files</span></p>
                                <p class="mb-1"><i class="fa fa-check mr-3 text-success"></i><span>1 Domain Free</span></p>
                            </div>
                            <p class="text-center pt-4"><a href="https://www.froala.com" class="btn btn btns9 px-4 py-2 rounded-lg mt-4">Try It Now</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </section>


        <!-- section3 -->
        <section class="section3 pb-3">
            <div class="container mt-3">
                <!-- Swiper -->
                <div class="swiper-container py-4 swiper4">
                    <div class="swiper-wrapper text-center">
                        <div class="swiper-slide">
                            <img class="rounded-circle mt-3 mb-3 col-3" src="assets/image/01.jpg">
                            <p class="mt-3">"that can provide everything you need to generate awareness, drive traffic, connect."</p>
                            <p class="text-blue">-Christa Smith-</p>
                        </div>
                        <div class="swiper-slide">
                            <img class="rounded-circle mt-3 mb-3 col-3" src="assets/image/02.jpg">
                            <p class="mt-3">"that can provide everything you need to generate awareness, drive traffic, connect."</p>
                            <p class="text-blue">-Christa Smith-</p>
                        </div>
                        <div class="swiper-slide">
                            <img class="rounded-circle mt-3 mb-3 col-3" src="assets/image/03.jpg">
                            <p class="mt-3">"that can provide everything you need to generate awareness, drive traffic, connect."</p>
                            <p class="text-blue">-Christa Smith-</p>
                        </div>
                        <div class="swiper-slide">
                            <img class="rounded-circle mt-3 mb-3 col-3" src="assets/image/04.jpg">
                            <p class="mt-3">"that can provide everything you need to generate awareness, drive traffic, connect."</p>
                            <p class="text-blue">-Christa Smith-</p>
                        </div>
                        <div class="swiper-slide">
                            <img class="rounded-circle mt-3 mb-3 col-3" src="assets/image/01.jpg">
                            <p class="mt-3">"that can provide everything you need to generate awareness, drive traffic, connect."</p>
                            <p class="text-blue">-Christa Smith-</p>
                        </div>
                        <div class="swiper-slide">
                            <img class="rounded-circle mt-3 mb-3 col-3" src="assets/image/02.jpg">
                            <p class="mt-3">"that can provide everything you need to generate awareness, drive traffic, connect."</p>
                            <p class="text-blue">-Christa Smith-</p>
                        </div>
                    </div><br><br>
                    <div class="swiper-pagination text-center pr-3 pb-3">
                        <div class="swiper-pagination wdt bg-white p-3 txt2 text-center mb-0"></div>
                    </div>
                </div>
            </div>
        </section>


        <!-- Contents 22 -->
        <section class="py-5">
            <div class="container pb-5">
                <div class="row text-center">
                    <div class="col-md-8 mx-auto">
                        <h3>Get the App now !</h3>
                        <p class="mt-3 col-md-8 mx-auto">Start working with <b class="text-blue">Landrick</b> that can provide everything you need to generate awareness, drive traffic, connect.</p>
                        <p>
                            <a class="btn btn btns9 px-4 py-2 mt-4" href="#"><small><i class="fab fa-apple mr-2"></i></small> App Store</a>
                            <a class="btn btn btns10 px-4 py-2 ml-2 mt-4" href="#"><small><i class="fab fa-google-play mr-2"></i></small> Play Store</a> 
                        </p>
                    </div>
                </div>
            </div>
        </section>
        

        <!-- footer -->
        <footer>
            <?php include("footer.php"); ?>
        </footer>
    </main>

<!-- bootstrap 4.4.1 -->
<script src="assets/bootstrap-4.4.1/js/jquery-3.4.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="assets/bootstrap-4.4.1/js/bootstrap.min.js"></script>
<!-- page-scrollreveal-3.3.2 -->
<script src="assets/page-scrollreveal-3.3.2/scrollreveal.min.js"></script>
<!-- swipre-master -->
<script src="assets/swiper-master/package/js/swiper.min.js"></script>

<!-- javascript.js --> 
<script src="assets/js/common.js"></script>          
<script src="assets/js/mobile-apps.js"></script>
    
</body>
</html>