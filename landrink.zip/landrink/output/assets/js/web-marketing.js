$(function(){ 
    // counter
    jQuery(window).scroll(startCounter);
    function startCounter() {
        var hT = jQuery('.count-this').offset().top,
            hH = jQuery('.count-this').outerHeight(),
            wH = jQuery(window).height();
        if (jQuery(window).scrollTop() > hT+hH-wH) {
            jQuery(window).off("scroll", startCounter);
            jQuery('.count-this').each(function () {
                var $this = jQuery(this);
                var t=$this.data('text')
                jQuery({ Counter: 0 }).animate({ Counter: $this.text() }, {
                    duration: 2000,
                    easing: 'swing',
                    step: function () {
                        $this.text(Math.ceil(this.Counter) + t);
                    }
                });
            });
        }
    }


    // swiper-master    
    var swiper4 = new Swiper( '.swiper4', {
        spaceBetween: 20,
        loop: true,
        slidesPerView: 1,

        autoplay: {
            delay: 5000,
        },
        pagination: {
          el: '.swiper-pagination',
          clickable: true,
          dynamicBullets: true,
      }, 
      
      // Responsive breakpoints
      breakpoints: {
        // when window width is <= 480px
        480: {
          slidesPerView: 1,
          spaceBetween: 20
        },
        // when window width is <= 640px
        768: {
          slidesPerView: 2,
          spaceBetween: 20
        },
        // when window width is <= 640px
        992: {
          slidesPerView: 3,
          spaceBetween: 20
        }
      },  
    } );

 });