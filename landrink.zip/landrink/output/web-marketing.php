<?php $page= "web-marketing";?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name=”description”>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<title>xyz</title>

<!-- normalize -->
<link rel="stylesheet" href="assets/css/normalize.min.css">
<!-- fav-icon -->    
<link rel="shortcut icon" href="assets/image/brand1.png"> 
<!-- Bootstrap 4.4.1-->
<link rel="stylesheet" href="assets/bootstrap-4.4.1/css/bootstrap.min.css">
<!-- Font-Awesome-5 -->
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
<!-- google-fonts -->    
<link href="https://fonts.googleapis.com/css2?family=Nunito:ital,wght@0,200;0,300;0,400;0,600;0,700;0,800;0,900;1,200;1,300;1,400;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
<!-- hover-master -->
<link rel="stylesheet" href="assets/Hover-master/css/hover.css">
<!-- swipre-master -->
<link rel="stylesheet" href="assets/swiper-master/package/css/swiper.css">
<!-- poppup video -->
<link rel="stylesheet" href="assets/poppup-video-jquary-3.2.1/grt-youtube-popup.min.css">
<!-- style.css -->
<link rel="stylesheet" href="assets/css/style.css">

</head>
<body>
    <main>
        
          <!-- Contents 22 -->
          <section class="web-market1 pb-5">
            <!-- header -->
            <header>
                <?php include("header.php"); ?>
            </header>

            <div class="container pb-5 mt-5 pt-5">
                <div class="row text-center pb-5">
                    <div class="col-md-7 mx-auto">
                        <img class="col-md-9 mb-5" src="assets/image//marketing.png">
                        <h1>Social Media Marketing is the Best Ever</h1>
                        <p class="mt-3 col-md-11 mx-auto p2">Launch your campaign and benefit from our expertise on designing and managing conversion centered bootstrap4 html page.</p>
                        <p class="h3 mt-5"><a href="#" class="btn btn px-4 py-2 btns9">Get Started</a> <a href="#" class="btn btn btns10 px-4 py-2 ml-3">Contact us <i class="fa fa-phone ml-2 fa-xs"></i></a></p>
                    </div>
                </div>
            </div>
        </section>


        <hr>
        <!-- Contents 14 -->
        <section class="pb-5 pt-3 mb-5">
            <div class="container">
                <div class="row text-center">
                    <div class="col-12 col-lg-2 col-md-4 mt-4">
                        <img alt="image" class="img-fluid col-8" src="assets/image/amazon.svg">
                    </div>
                    <div class="col-12 col-lg-2 col-md-4 mt-4">
                        <img alt="image" class="img-fluid col-8" src="assets/image/google.svg">
                    </div>
                    <div class="col-12 col-lg-2 col-md-4 mt-4">
                        <img alt="image" class="img-fluid col-8" src="assets/image/lenovo.svg">
                    </div>
                    <div class="col-12 col-lg-2 col-md-4 mt-4">
                        <img alt="image" class="img-fluid col-8" src="assets/image/paypal.svg">
                    </div>
                    <div class="col-12 col-lg-2 col-md-4 mt-4">
                        <img alt="image" class="img-fluid col-8" src="assets/image/shopify.svg">
                    </div>
                    <div class="col-12 col-lg-2 col-md-4 mt-4">
                        <img alt="image" class="img-fluid col-8" src="assets/image/spotify.svg">
                    </div>
                </div>
            </div>
        </section>


        <!-- Feature 9 -->
        <section class="bg-light py-5">
            <div class="container pt-5">
                <div class="row text-center">
                    <div class="col-md-6 mx-auto">
                        <h2>Sample Features</h2>
                        <p class="mt-3">Start working with <b class="text-blue">Landrick</b> that can provide everything you need to generate awareness, drive traffic, connect.</p>
                    </div>
                </div>
                <div class="row mt-4 text-md-left text-center">
                    <div class="col-12 col-lg-4 col-md-6 mt-4">
                        <div class="shadow-sm bg-white p-3 rounded-lg hvr-grow2 w-100">
                            <div class="row">
                                <div class="col-md-2">
                                    <span class="fa-stack fa-lg mt-md-0 mt-2">
                                        <i class="fa fa-circle fa-stack-2x text-grey3"></i>
                                        <i class="fas fa-desktop fa-stack-1x text-blue fntt1"></i>
                                    </span>
                                </div>
                                <div class="col-md-10 mt-2 pt-1">
                                    <h6>Fully Responsive</h6>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-lg-4 col-md-6 mt-4">
                        <div class="shadow-sm bg-white p-3 rounded-lg hvr-grow2 w-100">
                            <div class="row">
                                <div class="col-md-2">
                                    <span class="fa-stack fa-lg mt-md-0 mt-2">
                                        <i class="fa fa-circle fa-stack-2x text-grey3"></i>
                                        <i class="far fa-heart fa-stack-1x text-blue fntt1"></i>
                                    </span>
                                </div>
                                <div class="col-md-10 mt-2 pt-1">
                                    <h6>Browser Compatibility</h6>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-lg-4 col-md-6 mt-4">
                        <div class="shadow-sm bg-white p-3 rounded-lg hvr-grow2 w-100">
                            <div class="row">
                                <div class="col-md-2">
                                    <span class="fa-stack fa-lg mt-md-0 mt-2">
                                        <i class="fa fa-circle fa-stack-2x text-grey3"></i>
                                        <i class="fas fa-eye fa-stack-1x text-blue fntt1"></i>
                                    </span>
                                </div>
                                <div class="col-md-10 mt-2 pt-1">
                                    <h6>Retina Ready</h6>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-12 col-lg-4 col-md-6 mt-4">
                        <div class="shadow-sm bg-white p-3 rounded-lg hvr-grow2 w-100">
                            <div class="row">
                                <div class="col-md-2">
                                    <span class="fa-stack fa-lg mt-md-0 mt-2">
                                        <i class="fa fa-circle fa-stack-2x text-grey3"></i>
                                        <i class="fas fa-bold fa-stack-1x text-blue fntt1"></i>
                                    </span>
                                </div>
                                <div class="col-md-10 mt-2 pt-1">
                                    <h6>Based On Bootstrap 4</h6>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-lg-4 col-md-6 mt-4">
                        <div class="shadow-sm bg-white p-3 rounded-lg hvr-grow2 w-100">
                            <div class="row">
                                <div class="col-md-2">
                                    <span class="fa-stack fa-lg mt-md-0 mt-2">
                                        <i class="fa fa-circle fa-stack-2x text-grey3"></i>
                                        <i class="fa fa-user fa-stack-1x text-blue fntt1"></i>
                                    </span>
                                </div>
                                <div class="col-md-10 mt-2 pt-1">
                                    <h6>Feather Icons</h6>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-lg-4 col-md-6 mt-4">
                        <div class="shadow-sm bg-white p-3 rounded-lg hvr-grow2 w-100">
                            <div class="row">
                                <div class="col-md-2">
                                    <span class="fa-stack fa-lg mt-md-0 mt-2">
                                        <i class="fa fa-circle fa-stack-2x text-grey3"></i>
                                        <i class="fa fa-user fa-stack-1x text-blue fntt1"></i>
                                    </span>
                                </div>
                                <div class="col-md-10 mt-2 pt-1">
                                    <h6>Built With SASS</h6>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-12 col-lg-4 col-md-6 mt-4">
                        <div class="shadow-sm bg-white p-3 rounded-lg hvr-grow2 w-100">
                            <div class="row">
                                <div class="col-md-2">
                                    <span class="fa-stack fa-lg mt-md-0 mt-2">
                                        <i class="fa fa-circle fa-stack-2x text-grey3"></i>
                                        <i class="fas fa-user-check fa-stack-1x text-blue fntt1"></i>
                                    </span>
                                </div>
                                <div class="col-md-10 mt-2 pt-1">
                                    <h6>W3c Valid Code</h6>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-lg-4 col-md-6 mt-4">
                        <div class="shadow-sm bg-white p-3 rounded-lg hvr-grow2 w-100">
                            <div class="row">
                                <div class="col-md-2">
                                    <span class="fa-stack fa-lg mt-md-0 mt-2">
                                        <i class="fa fa-circle fa-stack-2x text-grey3"></i>
                                        <i class="fa fa-user fa-stack-1x text-blue fntt1"></i>
                                    </span>
                                </div>
                                <div class="col-md-10 mt-2 pt-1">
                                    <h6>Flaticon Icons</h6>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-lg-4 col-md-6 mt-4">
                        <div class="shadow-sm bg-white p-3 rounded-lg hvr-grow2 w-100">
                            <div class="row">
                                <div class="col-md-2">
                                    <span class="fa-stack fa-lg mt-md-0 mt-2">
                                        <i class="fa fa-circle fa-stack-2x text-grey3"></i>
                                        <i class="fas fa-cog fa-stack-1x text-blue fntt1"></i>
                                    </span>
                                </div>
                                <div class="col-md-10 mt-2 pt-1">
                                    <h6>Easy to customize</h6>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-12 text-center">
                        <p class="h3 mt-5"><a href="#" class="btn btn px-4 py-2 btns9">See More <i class="fa fa-chevron-right fa-xs ml-2"></i></a></p>
                    </div>
                </div>
            </div>
        </section>


        <!-- Feature 9 -->
        <section class="bg-light pb-5">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-12 col-md-5 mt-5">
                        <img src="assets/image/youtube-media.svg">
                    </div>
                    <div class="col-12 col-md-7 pl-md-5 mt-5">
                        <h2>A better compose with landrick marketing</h2>
                        <p class="mt-4">You can combine all the Landrick templates into a single one, you can take a component from the Application theme and use it in the Website.</p>
                        <div class="mt-4">
                            <p class="mb-1"><i class="far fa-check-circle mr-3 text-success"></i><span>Digital Marketing Solutions for Tomorrow</span></p>
                            <p class="mb-1"><i class="far fa-check-circle mr-3 text-success"></i><span>Our Talented & Experienced Marketing Agency</span></p>
                            <p class="mb-1"><i class="far fa-check-circle mr-3 text-success"></i><span>Create your own skin to match your brand</span></p>
                        </div>
                    </div>
                </div>
            </div>
        </section>


        <!-- section3 -->
        <section class="section3 bg-light py-5">
            <div class="container mt-3">
                <div class="row text-center">
                    <div class="col-md-6 mx-auto">
                        <h2>Our Valuable Clients</h2>
                        <p class="mt-3">Start working with <b class="text-blue">Landrick</b> that can provide everything you need to generate awareness, drive traffic, connect.</p>
                    </div>
                </div>
                <!-- Swiper -->
                <div class="swiper-container py-4 mt-3 swiper4">
                    <div class="swiper-wrapper">
                        <div class="swiper-slide">
                            <div class="row">
                                <div class="col-md-3">
                                    <img class="rounded-lg w-100" src="assets/image/01.jpg">
                                </div>
                                <div class="col-md-9 pl-md-0">
                                    <div class="shadow-sm bg-white p-4">
                                        <div>
                                            <i class="fa fa-star fa-xs text-orange"></i>
                                            <i class="fa fa-star fa-xs text-orange ml-1"></i>
                                            <i class="fa fa-star fa-xs text-orange ml-1"></i>
                                            <i class="fa fa-star fa-xs text-orange ml-1"></i>
                                            <i class="fa fa-star fa-xs text-orange ml-1"></i>
                                        </div>
                                        <p class="mt-3">"that can provide everything you need to generate awareness, drive traffic, connect."</p>
                                        <p class="text-blue mb-0">-Christa Smith <span class="text-grey2">Manager</span></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="row">
                                <div class="col-md-3">
                                    <img class="rounded-lg w-100" src="assets/image/02.jpg">
                                </div>
                                <div class="col-md-9 pl-md-0">
                                    <div class="shadow-sm bg-white p-4">
                                        <div>
                                            <i class="fa fa-star fa-xs text-orange"></i>
                                            <i class="fa fa-star fa-xs text-orange ml-1"></i>
                                            <i class="fa fa-star fa-xs text-orange ml-1"></i>
                                            <i class="fa fa-star fa-xs text-orange ml-1"></i>
                                            <i class="fa fa-star fa-xs text-orange ml-1"></i>
                                        </div>
                                        <p class="mt-3">"that can provide everything you need to generate awareness, drive traffic, connect."</p>
                                        <p class="text-blue mb-0">-Thomas Israil <span class="text-grey2">Manager</span></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="row">
                                <div class="col-md-3">
                                    <img class="rounded-lg w-100" src="assets/image/03.jpg">
                                </div>
                                <div class="col-md-9 pl-md-0">
                                    <div class="shadow-sm bg-white p-4">
                                        <div>
                                            <i class="fa fa-star fa-xs text-orange"></i>
                                            <i class="fa fa-star fa-xs text-orange ml-1"></i>
                                            <i class="fa fa-star fa-xs text-orange ml-1"></i>
                                            <i class="fa fa-star fa-xs text-orange ml-1"></i>
                                            <i class="fa fa-star fa-xs text-orange ml-1"></i>
                                        </div>
                                        <p class="mt-3">"that can provide everything you need to generate awareness, drive traffic, connect."</p>
                                        <p class="text-blue mb-0">-Dean Toll <span class="text-grey2">Manager</span></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="row">
                                <div class="col-md-3">
                                    <img class="rounded-lg w-100" src="assets/image/04.jpg">
                                </div>
                                <div class="col-md-9 pl-md-0">
                                    <div class="shadow-sm bg-white p-4">
                                        <div>
                                            <i class="fa fa-star fa-xs text-orange"></i>
                                            <i class="fa fa-star fa-xs text-orange ml-1"></i>
                                            <i class="fa fa-star fa-xs text-orange ml-1"></i>
                                            <i class="fa fa-star fa-xs text-orange ml-1"></i>
                                            <i class="fa fa-star fa-xs text-orange ml-1"></i>
                                        </div>
                                        <p class="mt-3">"that can provide everything you need to generate awareness, drive traffic, connect."</p>
                                        <p class="text-blue mb-0">-Christa Smith <span class="text-grey2">Manager</span></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="row">
                                <div class="col-md-3">
                                    <img class="rounded-lg w-100" src="assets/image/01.jpg">
                                </div>
                                <div class="col-md-9 pl-md-0">
                                    <div class="shadow-sm bg-white p-4">
                                        <div>
                                            <i class="fa fa-star fa-xs text-orange"></i>
                                            <i class="fa fa-star fa-xs text-orange ml-1"></i>
                                            <i class="fa fa-star fa-xs text-orange ml-1"></i>
                                            <i class="fa fa-star fa-xs text-orange ml-1"></i>
                                            <i class="fa fa-star fa-xs text-orange ml-1"></i>
                                        </div>
                                        <p class="mt-3">"that can provide everything you need to generate awareness, drive traffic, connect."</p>
                                        <p class="text-blue mb-0">-Thomas Israil <span class="text-grey2">Manager</span></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="row">
                                <div class="col-md-3">
                                    <img class="rounded-lg w-100" src="assets/image/02.jpg">
                                </div>
                                <div class="col-md-9 pl-md-0">
                                    <div class="shadow-sm bg-white p-4">
                                        <div>
                                            <i class="fa fa-star fa-xs text-orange"></i>
                                            <i class="fa fa-star fa-xs text-orange ml-1"></i>
                                            <i class="fa fa-star fa-xs text-orange ml-1"></i>
                                            <i class="fa fa-star fa-xs text-orange ml-1"></i>
                                            <i class="fa fa-star fa-xs text-orange ml-1"></i>
                                        </div>
                                        <p class="mt-3">"that can provide everything you need to generate awareness, drive traffic, connect."</p>
                                        <p class="text-blue mb-0">-Dean Toll <span class="text-grey2">Manager</span></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div><br><br>
                    <div class="swiper-pagination text-center pr-3 pb-3">
                        <div class="swiper-pagination wdt bg-white p-3 txt2 text-center mb-0"></div>
                    </div>
                </div>
            </div>
        </section>


        <!-- Feature 9 -->
        <section class="py-5">
            <div class="container pt-5">
                <div class="row text-center">
                    <div class="col-md-6 mx-auto">
                        <h2>See everything about your <span class="text-blue">Landrick</span></h2>
                        <p class="mt-3">Start working with <b class="text-blue">Landrick</b> that can provide everything you need to generate awareness, drive traffic, connect.</p>
                    </div>
                </div>
                <div class="row mt-4 tex-md-left text-center">
                    <div class="col-12 col-lg-3 col-md-6 mt-4">
                        <img class="col-md-4" src="assets/image/Asset190.svg">
                        <h2 class="display-4 mt-3 count-this" data-text="%">97</h2>
                        <p>Happy Client</p>
                    </div>
                    <div class="col-12 col-lg-3 col-md-6 mt-4">
                        <img class="col-md-4" src="assets/image/Asset189.svg">
                        <h2 class="display-4 mt-3 count-this" data-text="+">15</h2>
                        <p>Awards</p>
                    </div>
                    <div class="col-12 col-lg-3 col-md-6 mt-4">
                        <img class="col-md-4" src="assets/image/Asset192.svg">
                        <h2 class="display-4 mt-3 count-this" data-text="K">2</h2>
                        <p>Job Placement</p>
                    </div>
                    <div class="col-12 col-lg-3 col-md-6 mt-4">
                        <img class="col-md-4" src="assets/image/Asset187.svg">
                        <h2 class="display-4 mt-3 count-this" data-text="%">98</h2>
                        <p>Project Complete</p>
                    </div>
                </div>
            </div>
        </section>


        <!-- Feature 9 -->
        <section class="pb-5">
            <div class="container">
                <div class="row">
                    <div class="col-12 col-md-7 mt-5">
                        <div id="accordion">
                            <div class="card-header py-3 border-0 mt-3">
                                <a class="card-link text-hvr1 text-black1 d-flex justify-content-between" data-toggle="collapse" href="#collapseOne">
                                    <span>How our <span class="text-blue">Landrick</span> work ?</span>
                                    <i class="fa fa-chevron-down fa-xs mt-2"></i>
                                </a>
                            </div>
                            <div id="collapseOne" class="collapse show" data-parent="#accordion">
                                <div class="card-body bg-white">
                                    <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form.</p>
                                </div>
                            </div>

                            <div class="card-header py-3 border-0 mt-3">
                                <a class="card-link text-hvr1 text-black1 d-flex justify-content-between" data-toggle="collapse" href="#collapsetwo">
                                    <span>What is the main process open account ?</span>
                                    <i class="fa fa-chevron-down fa-xs mt-2"></i>
                                </a>
                            </div>
                            <div id="collapsetwo" class="collapse" data-parent="#accordion">
                                <div class="card-body bg-white">
                                    <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form.</p>
                                </div>
                            </div>

                            <div class="card-header py-3 border-0 mt-3">
                                <a class="card-link text-hvr1 text-black1 d-flex justify-content-between" data-toggle="collapse" href="#collapsethree">
                                    <span>How to make unlimited data entry ?</span>
                                    <i class="fa fa-chevron-down fa-xs mt-2"></i>
                                </a>
                            </div>
                            <div id="collapsethree" class="collapse" data-parent="#accordion">
                                <div class="card-body bg-white">
                                    <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form.</p>
                                </div>
                            </div>

                            <div class="card-header py-3 border-0 mt-3">
                                <a class="card-link text-hvr1 text-black1 d-flex justify-content-between" data-toggle="collapse" href="#collapsefour">
                                    <span>Is <span class="text-blue">Landrick</span> safer to use with my account ?</span>
                                    <i class="fa fa-chevron-down fa-xs mt-2"></i>
                                </a>
                            </div>
                            <div id="collapsefour" class="collapse" data-parent="#accordion">
                                <div class="card-body bg-white">
                                    <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form.</p>
                                </div>
                            </div>

                            <div class="card-header py-3 border-0 mt-3">
                                <a class="card-link text-hvr1 text-black1 d-flex justify-content-between" data-toggle="collapse" href="#collapsefive">
                                    <span>How can i contact your technical team ?</span>
                                    <i class="fa fa-chevron-down fa-xs mt-2"></i>
                                </a>
                            </div>
                            <div id="collapsefive" class="collapse" data-parent="#accordion">
                                <div class="card-body bg-white">
                                    <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-md-5 pl-md-5 mt-5 pt-4">
                        <img class="w-100" src="assets/image/faq.svg">
                    </div>
                </div>
            </div>
        </section>


        <!-- Contents 22 -->
        <section class="py-5">
            <div class="container pb-5">
                <div class="row text-center">
                    <div class="col-md-8 mx-auto">
                        <h3>Get Started !</h3>
                        <p class="mt-4 col-md-9 mx-auto">Start working with  <span class="text-blue">Landrick</span> that can provide everything you need to generate awareness, drive traffic, connect.</p>
                        <p class="h3 mt-4 pt-2">
                            <a class="btn btn btns9 rounded-lg px-4 py-2" href="#"> Buy Now <span class="ml-2"><span class="bg-danger pb-1 pt-1 pl-2 fntt2 pr-2 btn-round text-white">v2.2</span></span></a>
                            <a class="text-decoration-none text-body youtube-link" href="#" youtubeid="qLCLvzTGFVM" class="ml-3"><span class="fa-stack fa-xs mt-1">
                                <i class="fa fa-circle fa-stack-2x text-blue"></i>
                                <i class="fa fa-play fa-stack-1x text-white mr-3 fntt2 pl-1"></i>
                            </span> <span class="fntt1">WATCH VIDEO</span></a>
                        </p>
                    </div>
                </div>
            </div>
        </section>


        <!-- footer -->
        <footer>
            <?php include("footer.php"); ?>
        </footer>
    </main>

<!-- bootstrap 4.4.1 -->
<script src="assets/bootstrap-4.4.1/js/jquery-3.4.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="assets/bootstrap-4.4.1/js/bootstrap.min.js"></script>
<!-- page-scrollreveal-3.3.2 -->
<script src="assets/page-scrollreveal-3.3.2/scrollreveal.min.js"></script>
<!-- swipre-master -->
<script src="assets/swiper-master/package/js/swiper.min.js"></script>
<!-- poppup video -->
<script src="assets/poppup-video-jquary-3.2.1/grt-youtube-popup.min.js"></script>

<!-- javascript.js --> 
<script src="assets/js/common.js"></script>          
<script src="assets/js/web-marketing.js"></script>
    
<script>
    //poppup video    
    $(".youtube-link").grtyoutube({
        autoPlay:true,
        theme: "dark"
    });
</script>

</body>
</html>