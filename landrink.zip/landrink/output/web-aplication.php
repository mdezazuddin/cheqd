<?php $page= "web-aplication";?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name=”description”>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<title>xyz</title>

<!-- normalize -->
<link rel="stylesheet" href="assets/css/normalize.min.css">
<!-- fav-icon -->    
<link rel="shortcut icon" href="assets/image/brand1.png"> 
<!-- Bootstrap 4.4.1-->
<link rel="stylesheet" href="assets/bootstrap-4.4.1/css/bootstrap.min.css">
<!-- Font-Awesome-5 -->
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
<!-- google-fonts -->    
<link href="https://fonts.googleapis.com/css2?family=Nunito:ital,wght@0,200;0,300;0,400;0,600;0,700;0,800;0,900;1,200;1,300;1,400;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
<!-- hover-master -->
<link rel="stylesheet" href="assets/Hover-master/css/hover.css">
<!-- swipre-master -->
<link rel="stylesheet" href="assets/swiper-master/package/css/swiper.css">
<!-- poppup video -->
<link rel="stylesheet" href="assets/poppup-video-jquary-3.2.1/grt-youtube-popup.min.css">
<!-- style.css -->
<link rel="stylesheet" href="assets/css/style.css">

</head>
<body>
    <main>
    
        <!-- Contents 14 -->
        <section class="web-apps1">
            <!-- header -->
            <header>
                <?php include("header.php"); ?>
            </header>

            <div class="container">
                <div class="row align-items-center">
                    <div class="col-12 col-lg-6 mt-4 ml-md-auto text-left">
                        <div class=" ptt8">
                            <h1 class="mt-4 font-weight-bold">We help to build
                                the project</h1>
                            <p class="mt-3 p2">Launch your campaign and benefit from our expertise on designing and managing conversion centered bootstrap4 html page.</p>
                            <p>
                                <a class="btn btn btns9 rounded-lg px-4 py-2 mt-4" href="#"> Buy Now <span class="ml-2"><span class="bg-danger pb-1 pt-1 pl-2 fntt2 pr-2 btn-round text-white">v2.2</span></span></a>
                            </p>
                        </div>
                    </div>
                    <div class="col-12 col-lg-6 mt-4 text-md-right">
                        <img class="w-100" src="assets/image/classic01.png">
                    </div>
                </div>
            </div>
        </section>


        <!-- Contents 14 -->
        <section class="py-5 mb-5 mt-md-5">
            <div class="container">
                <div class="row text-center">
                    <div class="col-12 col-lg-2 col-md-4 mt-4">
                        <img alt="image" class="img-fluid col-8" src="assets/image/amazon.svg">
                    </div>
                    <div class="col-12 col-lg-2 col-md-4 mt-4">
                        <img alt="image" class="img-fluid col-8" src="assets/image/google.svg">
                    </div>
                    <div class="col-12 col-lg-2 col-md-4 mt-4">
                        <img alt="image" class="img-fluid col-8" src="assets/image/lenovo.svg">
                    </div>
                    <div class="col-12 col-lg-2 col-md-4 mt-4">
                        <img alt="image" class="img-fluid col-8" src="assets/image/paypal.svg">
                    </div>
                    <div class="col-12 col-lg-2 col-md-4 mt-4">
                        <img alt="image" class="img-fluid col-8" src="assets/image/shopify.svg">
                    </div>
                    <div class="col-12 col-lg-2 col-md-4 mt-4">
                        <img alt="image" class="img-fluid col-8" src="assets/image/spotify.svg">
                    </div>
                </div>
            </div>
        </section>


        <!-- Feature 9 -->
        <section class="pb-5">
            <div class="container">
                <div class="row mt-4 text-center">
                    <div class="col-12 col-lg-4 col-md-6 mt-4 parent2">
                        <div class="parent2 mttl1">
                            <div class="child2 anim-des mttl3"><span class="p-5"></span></div>
                            <div class="layers2">
                                <img alt="image" class="w-25 fntts7 mt-4" src="assets/image/user.svg">
                            </div>
                        </div>
                        <h5>Easy To Use</h5>
                        <p class="mt-3">Nisi aenean vulputate eleifend tellus vitae eleifend enim a Aliquam eleifend aenean elementum semper.</p>
                    </div>
            
                    <div class="col-12 col-lg-4 col-md-6 mt-4 parent2">
                        <div class="parent2 mttl1">
                            <div class="child2 anim-des mttl3"><span class="p-5"></span></div>
                            <div class="layers2">
                                <img alt="image" class="w-25 fntts7 mt-4" src="assets/image/calendar.svg">
                            </div>
                        </div>
                        <h5>Daily Reports</h5>
                        <p class="mt-3">Allegedly, a Latin scholar established the origin of the established text by compiling unusual word.</p>
                    </div>
            
                    <div class="col-12 col-lg-4 col-md-6 mt-4 parent2">
                        <div class="parent2 mttl1">
                            <div class="child2 anim-des mttl3"><span class="p-5"></span></div>
                            <div class="layers2">
                                <img alt="image" class="w-25 fntts7 mt-4" src="assets/image/sand-clock.svg">
                            </div>
                        </div>
                        <h5>Real Time Zone</h5>
                        <p class="mt-3">It seems that only fragments of the original text remain in only fragments the Lorem Ipsum texts used today.</p>
                    </div>
                </div>
            </div>
        </section>


        <!-- Feature 9 -->
        <section class="py-5 web-apps3">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-12 col-md-7 mt-5">
                        <img class="w-100" src="assets/image/classic02.png">
                    </div>
                    <div class="col-12 col-md-5 pl-md-5 mt-5">
                        <h2>Build your site for using this app</h2>
                        <p class="mt-4">Launch your campaign and benefit from our expertise on designing and managing conversion centered bootstrap4 html page.</p>
                        <div class="mt-4">
                            <!-- Swiper -->
                            <div class="swiper-container swiper5">
                                <div class="swiper-wrapper text-left">
                                    <div class="swiper-slide">
                                        <img class="rounded-circle mt-3 mb-3 col-3" src="assets/image/01.jpg">
                                        <p class="mt-3">"that can provide everything you need to generate awareness, drive traffic, connect."</p>
                                        <p class="text-blue">-Christa Smith-</p>
                                    </div>
                                    <div class="swiper-slide">
                                        <img class="rounded-circle mt-3 mb-3 col-3" src="assets/image/02.jpg">
                                        <p class="mt-3">"that can provide everything you need to generate awareness, drive traffic, connect."</p>
                                        <p class="text-blue">-Christa Smith-</p>
                                    </div>
                                    <div class="swiper-slide">
                                        <img class="rounded-circle mt-3 mb-3 col-3" src="assets/image/03.jpg">
                                        <p class="mt-3">"that can provide everything you need to generate awareness, drive traffic, connect."</p>
                                        <p class="text-blue">-Christa Smith-</p>
                                    </div>
                                    <div class="swiper-slide">
                                        <img class="rounded-circle mt-3 mb-3 col-3" src="assets/image/04.jpg">
                                        <p class="mt-3">"that can provide everything you need to generate awareness, drive traffic, connect."</p>
                                        <p class="text-blue">-Christa Smith-</p>
                                    </div>
                                    <div class="swiper-slide">
                                        <img class="rounded-circle mt-3 mb-3 col-3" src="assets/image/01.jpg">
                                        <p class="mt-3">"that can provide everything you need to generate awareness, drive traffic, connect."</p>
                                        <p class="text-blue">-Christa Smith-</p>
                                    </div>
                                    <div class="swiper-slide">
                                        <img class="rounded-circle mt-3 mb-3 col-3" src="assets/image/02.jpg">
                                        <p class="mt-3">"that can provide everything you need to generate awareness, drive traffic, connect."</p>
                                        <p class="text-blue">-Christa Smith-</p>
                                    </div>
                                </div><br><br>
                                <div class="swiper-pagination text-center pr-3 pb-3">
                                    <div class="swiper-pagination wdt bg-white p-3 txt2 text-center mb-0"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>


        <!-- Feature 9 -->
        <section class="pt-4 pb-5 web-apps2">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-12 col-md-5 pl-md-5 mt-5">
                        <h2>Why Choose us ?</h2>
                        <p class="mt-4">Launch your campaign and benefit from our expertise on designing and managing conversion centered bootstrap4 html page.</p>
                        <div class="mt-5">
                            <div class="row">
                                <div class="col-1">
                                    <i class="fas fa-user-check text-blue fa-lg"></i>
                                </div>
                                <div class="col-11">
                                    <h5>Fully Secured</h5>
                                    <p class="mt-2">Moreover, in Latin only words at the beginning of sentences are capitalized.</p>
                                </div>
                            </div>
                            <div class="row mt-4">
                                <div class="col-1">
                                    <i class="fas fa-cog text-blue fa-lg"></i>
                                </div>
                                <div class="col-11">
                                    <h5>Best Performance</h5>
                                    <p class="mt-2">If the fill text is intended to illustrate the characteristics of sometimes.</p>
                                </div>
                            </div>
                        </div>
                        <p>
                            <a class="btn btn btns10 rounded-lg px-4 py-2 mt-4" href="#"> Install Now <span class="fa fa-chevron-right fntt2 ml-2"></span></a>
                        </p>
                    </div>
                    <div class="col-12 col-md-7 pl-md-5 mt-5">
                        <img class="w-100" src="assets/image/classic02.png">
                    </div>
                </div>
            </div>
        </section>


        <!-- Contents 22 -->
        <section class="py-5">
            <div class="container pb-5">
                <div class="row text-center">
                    <div class="col-md-8 mx-auto">
                        <h3>Overall <span class="text-blue count-this" data-text="K+">333</span> client are using, Get Started</h3>
                        <p class="mt-4 col-md-9 mx-auto">Build responsive, mobile-first projects on the web with the world's most popular front-end component library.</p>
                        <p class="h3 mt-4 pt-2">
                            <a href="#" class="btn btn px-4 py-2 btns9">Get Started <span class="fa fa-chevron-right fntt2 ml-2"></span></a> 
                            <a class="text-decoration-none text-body youtube-link" href="#" youtubeid="qLCLvzTGFVM" class="ml-3"><span class="fa-stack fa-xs mt-1">
                                <i class="fa fa-circle fa-stack-2x text-blue"></i>
                                <i class="fa fa-play fa-stack-1x text-white mr-3 fntt2 pl-1"></i>
                            </span> <span class="fntt1">WATCH VIDEO</span></a>
                        </p>
                    </div>
                </div>
            </div>
        </section>


        <!-- Pricings 5 -->
        <section class="py-md--5">
            <div class="container py-md-5">
                <div class="row text-center">
                    <div class="col-md-6 mx-auto">
                        <h2>Our Pricing Rates</h2>
                        <p class="mt-3">Start working with <b class="text-blue">Landrick</b> that can provide everything you need to generate awareness, drive traffic, connect.</p>
                    </div>
                </div>
        
                <div class="row mt-5">
                    <div class="col-12 col-md-6 p-3 col-lg-3">
                        <div class="bg-light pb-2 pt-4 pl-4 pr-4 rounded-right hvr-grow w-100 card7">
                            <h6 class="font-weight-bold clr2">FREE</h6>
                            <p class="mt-4 mb-5 text-body"><strong><sup class="h5 text-body">$</sup></strong> <strong><sub class="h1">0</sub></strong> <strong><sub class="h4 text-body">/mo</sub></strong></p>
                            <div>
                                <p class="mb-1"><i class="fa fa-check mr-3 text-success"></i><span>Full Access</span></p>
                                <p class="mb-1"><i class="fa fa-check mr-3 text-success"></i><span>Enhanced Security</span></p>
                            </div>
                            <p class="pt-4"><a href="https://www.froala.com" class="btn btn btns9 px-4 py-2 rounded-lg mt-4">Buy Now</a></p>
                        </div>
                    </div>
            
                    <div class="col-12 col-md-6 p-3 col-lg-3">
                        <div class="bg-white shadow-sm pb-2 pt-4 pl-4 pr-4 rounded-right hvr-grow w-100 card7">
                            <h6 class="font-weight-bold clr2 text-blue">STARTER</h6>
                            <p class="mt-4 mb-5 text-body"><strong><sup class="h5 text-body">$</sup></strong> <strong><sub class="h1">39</sub></strong> <strong><sub class="h4 text-body">/mo</sub></strong></p>
                            <div>
                                <p class="mb-1"><i class="fa fa-check mr-3 text-success"></i><span>Full Access</span></p>
                                <p class="mb-1"><i class="fa fa-check mr-3 text-success"></i><span>Enhanced Security</span></p>
                                <p class="mb-1"><i class="fa fa-check mr-3 text-success"></i><span>Free Appointments</span></p>
                            </div>
                            <p class="pt-4"><a href="https://www.froala.com" class="btn btn btns9 px-4 py-2 rounded-lg mt-4">Get Started</a></p>
                        </div>
                    </div>
            
                    <div class="col-12 col-md-6 p-3 col-lg-3">
                        <div class="bg-light pb-2 pt-4 pl-4 pr-4 rounded-right hvr-grow w-100 card7">
                            <h6 class="font-weight-bold clr2">PROFESSIONAL</h6>
                            <p class="mt-4 mb-5 text-body"><strong><sup class="h5 text-body">$</sup></strong> <strong><sub class="h1">59</sub></strong> <strong><sub class="h4 text-body">/mo</sub></strong></p>
                            <div>
                                <p class="mb-1"><i class="fa fa-check mr-3 text-success"></i><span>Full Access</span></p>
                                <p class="mb-1"><i class="fa fa-check mr-3 text-success"></i><span>Enhanced Security</span></p>
                                <p class="mb-1"><i class="fa fa-check mr-3 text-success"></i><span>1 Domain Free</span></p>
                                <p class="mb-1"><i class="fa fa-check mr-3 text-success"></i><span>Enhanced Security</span></p>
                            </div>
                            <p class="pt-4"><a href="https://www.froala.com" class="btn btn btns9 px-4 py-2 rounded-lg mt-4">Try It Now</a></p>
                        </div>
                    </div>

                    <div class="col-12 col-md-6 p-3 col-lg-3">
                        <div class="bg-light pb-2 pt-4 pl-4 pr-4 rounded-right hvr-grow w-100 card7">
                            <h6 class="font-weight-bold clr2">ULTIMATE</h6>
                            <p class="mt-4 mb-5 text-body"><strong><sup class="h5 text-body">$</sup></strong> <strong><sub class="h1">79</sub></strong> <strong><sub class="h4 text-body">/mo</sub></strong></p>
                            <div>
                                <p class="mb-1"><i class="fa fa-check mr-3 text-success"></i><span>Full Access</span></p>
                                <p class="mb-1"><i class="fa fa-check mr-3 text-success"></i><span>Enhanced Security</span></p>
                                <p class="mb-1"><i class="fa fa-check mr-3 text-success"></i><span>Source Files</span></p>
                                <p class="mb-1"><i class="fa fa-check mr-3 text-success"></i><span>1 Domain Free</span></p>
                                <p class="mb-1"><i class="fa fa-check mr-3 text-success"></i><span>Free Installment</span></p>
                            </div>
                            <p class="pt-4"><a href="https://www.froala.com" class="btn btn btns9 px-4 py-2 rounded-lg mt-4">Started Now</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </section>


          <!-- Contents 22 -->
          <section class="py-5">
            <div class="container pb-5">
                <div class="bg-blue p-5 rounded-lg">
                    <div class="row text-white">
                        <div class="col-md-8">
                            <h3>Start your free 2 week trial today</h3>
                            <p class="mt-3 text-grey3">Start working with Landrick that can provide everything you need to generate awareness, drive traffic, connect.</p>
                        </div>
                        <div class="col-md-4 text-md-right">
                            <p class="h3 mt-5"><a href="#" class="btn btn-light rounded-lg px-4 py-2">Get Started</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        

        <!-- footer -->
        <footer>
            <?php include("footer.php"); ?>
        </footer>
    </main>

<!-- bootstrap 4.4.1 -->
<script src="assets/bootstrap-4.4.1/js/jquery-3.4.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="assets/bootstrap-4.4.1/js/bootstrap.min.js"></script>
<!-- page-scrollreveal-3.3.2 -->
<script src="assets/page-scrollreveal-3.3.2/scrollreveal.min.js"></script>
<!-- swipre-master -->
<script src="assets/swiper-master/package/js/swiper.min.js"></script>
<!-- poppup video -->
<script src="assets/poppup-video-jquary-3.2.1/grt-youtube-popup.min.js"></script>

<!-- javascript.js --> 
<script src="assets/js/common.js"></script>          
<script src="assets/js/web-aplication.js"></script>
    
<script>
    //poppup video    
    $(".youtube-link").grtyoutube({
        autoPlay:true,
        theme: "dark"
    });
</script>

</body>
</html>