
	<nav class="navbar navbar-expand-md p-md-0 nav1">
		<div class="container">
			<a class="navbar-brand pt-3 text-dark" href="index.php"><img class="" alt="Avatar" src="assets/image/logo@1x.png"></a>
			<button class="navbar-toggler navbar-light mr-3" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
				<span class="navbar-toggler-icon"></span>
			</button>
			<div class="collapse navbar-collapse" id="collapsibleNavbar">
				<ul class="navbar-nav mx-auto">
					<li class="nav-item">
						<a class="nav-link <?php if($page=="home"){echo "active-menu";} ?>" href="index.php">HOME</a>
					</li>
					<li class="nav-item pl-md-3">
						<a class="nav-link <?php if($page=="about"){echo "active-menu";} ?>" href="#">FEATURES</a>
					</li>
					<li class="nav-item pl-md-3">
						<a class="nav-link <?php if($page=="about"){echo "active-menu";} ?>" href="#">PRICING</a>
					</li>
					<li class="nav-item pl-md-3 hvr-icon-spin">
                        <div class="dropdown d-md-block d-none">
							<a class="nav-link <?php if($page=="service"){echo "active-menu";} ?>" href="service.php">SERVICE <i class="fa fa-chevron-down mt-1 ml-2 hvr-icon"></i></a>
                            <div class="dropdown-menu dropdown-content shadow-sm p-0">
								<a class="dropdown-item pt-2 pb-2 brd-bottom2 small <?php if($page=="mobile-apps"){echo "active-menu1";} ?>" href="mobile-apps.php">Mobile App</a>
								<a class="dropdown-item pt-2 pb-2 brd-bottom2 small <?php if($page=="web-marketing"){echo "active-menu1";} ?>" href="web-marketing.php">Web Marketing</a>
								<a class="dropdown-item pt-2 pb-2 brd-bottom2 small <?php if($page=="web-aplication"){echo "active-menu1";} ?>" href="web-aplication.php">Web Application</a>
                            </div>
                        </div>

                        <div class="d-md-none d-block mt-1">
                            <a class="collapsed card-link d-flex justify-content-between" data-toggle="collapse" href="#collapsefive">
                                <span>SERVICE</span><i class="fa fa-caret-down fa-lg"></i>
                            </a>
                            <div id="collapsefive" class="collapse card">
                                <div class="btns4">
								<a class="dropdown-item pt-2 pb-2 brd-bottom2 small <?php if($page=="mobile-apps"){echo "active-menu";} ?>" href="mobile-apps.php">Mobile App</a>
								<a class="dropdown-item pt-2 pb-2 brd-bottom2 small <?php if($page=="web-marketing"){echo "active-menu";} ?>" href="web-marketing.php">Web Marketing</a>
								<a class="dropdown-item pt-2 pb-2 brd-bottom2 small <?php if($page=="web-application"){echo "active-menu";} ?>" href="web-aplication.php">Web Application</a>
                                </div>
                            </div>
                        </div>
                    </li>
					<li class="nav-item pl-md-3 mt-md-0 mt-1">
						<a class="nav-link <?php if($page=="contact"){echo "active-menu";} ?>" href="contact.php">CONTACT</a>
					</li>    
				</ul>
			</div> 
			
			<div class="ml-auto d-md-block d-none">
				<a href="#" class="btn btn btn-sm rounded-pill px-4 pt-1 pb-2 btns9"><b>Login</b></a>
				<a href="#" class="btn btn btn-sm rounded-pill px-4 pt-1 pb-2 btns9 ml-3"><b>Sign up</b></a>
			</div>
		</div>
	</nav>


	<!--CSS Spinner-->
    <div class="spinner-wrapper">
        <div class="sk-cube-grid">
          <div class="sk-cube sk-cube1"></div>
          <div class="sk-cube sk-cube2"></div>
          <div class="sk-cube sk-cube3"></div>
          <div class="sk-cube sk-cube4"></div>
          <div class="sk-cube sk-cube5"></div>
          <div class="sk-cube sk-cube6"></div>
          <div class="sk-cube sk-cube7"></div>
          <div class="sk-cube sk-cube8"></div>
          <div class="sk-cube sk-cube9"></div>
        </div>
    </div>