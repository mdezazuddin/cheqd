<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name=”description”>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<title>blog</title>

<!-- normalize -->
<link rel="stylesheet" href="assets/css/normalize.min.css">
<!-- fav-icon -->    
<link rel="shortcut icon" href="assets/image/brand1.png"> 
<!-- Bootstrap 4.4.1-->
<link rel="stylesheet" href="assets/bootstrap-4.4.1/css/bootstrap.min.css">
<!-- Font-Awesome-5 -->
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
<!-- google-fonts -->    
<link href="https://fonts.googleapis.com/css2?family=Nunito:ital,wght@0,200;0,300;0,400;0,600;0,700;0,800;0,900;1,200;1,300;1,400;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
<!-- hover-master -->
<link rel="stylesheet" href="assets/Hover-master/css/hover.css">
<!-- style.css -->
<link rel="stylesheet" href="assets/css/style.css">

</head>
<body>
    <main>
        <!-- section1 -->
        <section class="section1 bg-error">
            <div class="container pt-5 pb-5">
                <div class="row pt-4">
                    <div class="col-lg-12 text-center">
                        <img class="col-md-5" src="assets/image/404.png">
                        <h2 class="display-4 mt-4">OH ! NO</h2>
                        <h1>Page Not Found</h1>
                        <p class="mt-4 col-md-7 mx-auto">Start working with <b class="text-blue">Landrick</b> that can provide everything you need to generate awareness, drive traffic, connect.</p>
                        <p class="h3 mt-5"><a href="#" class="btn btn btns10 px-4 py-2 ml-3">Go Back</a> <a href="#" class="btn btn px-4 py-2 btns9">G0 To Home</a></p>
                    </div>
                </div>
            </div>
        </section>
    </main>


<!-- bootstrap 4.4.1 -->
<script src="assets/bootstrap-4.4.1/js/jquery-3.4.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="assets/bootstrap-4.4.1/js/bootstrap.min.js"></script>
<!-- page-scrollreveal-3.3.2 -->
<script src="assets/page-scrollreveal-3.3.2/scrollreveal.min.js"></script>

<!-- javascript.js --> 
<script src="assets/js/common.js"></script>                 

</body>
</html>