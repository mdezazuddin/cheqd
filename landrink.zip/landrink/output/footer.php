    <!--footer-->
    <footer class="foot bg-blue2">
        <div class="container py-4">
            <div class="row pb-3 left-reveal">
                <div class="col-12 col-md-6 col-lg-4 mt-5">
                    <a class="navbar-brand text-white" href="index.php"><h4>Landrink</h4></a>
                    <p class="mt-3 text-grey2"> Start working with Landrick that can provide everything you need to generate awareness, drive traffic, connect.</p>
                    <div class="mt-3">
                        <a href="#" class="btn btn-outline-light btn-sm btns8 pxt3"><i class="fab fa-facebook-f"></i></a>
                        <a class="btn btn btn-sm btns8 ml-1" href="#"><i class="fab fa-instagram"></i></a>
                        <a class="btn btn btn-sm btns8 ml-1" href="#"><i class="fab fa-twitter"></i></a>
                        <a class="btn btn btn-sm btns8 ml-1" href="#"><i class="fab fa-linkedin-in"></i></a>
                    </div>
                </div>

                <div class="col-12 col-md-6 col-lg-2 mt-5">
                    <h5 class="mb-4 text-white">Company</h5>
                    <a class="text-decoration-none d-flex" href="#"> <i class="fa fa-chevron-right mt-2 mr-3 fntt2"></i> <span>About us</span></a>
                    <a class="text-decoration-none mt-3 d-flex" href="#"> <i class="fa fa-chevron-right mt-2 mr-3 fntt2"></i> <span>Services</span></a>
                    <a class="text-decoration-none mt-3 d-flex" href="#"> <i class="fa fa-chevron-right mt-2 mr-3 fntt2"></i> <span>Team</span></a>
                    <a class="text-decoration-none mt-3 d-flex" href="#"> <i class="fa fa-chevron-right mt-2 mr-3 fntt2"></i> <span>Pricing</span></a>
                    <a class="text-decoration-none mt-3 d-flex" href="#"> <i class="fa fa-chevron-right mt-2 mr-3 fntt2"></i> <span>Project</span></a>
                    <a class="text-decoration-none mt-3 d-flex" href="#"> <i class="fa fa-chevron-right mt-2 mr-3 fntt2"></i> <span>Careers</span></a>
                    <a class="text-decoration-none mt-3 d-flex" href="#"> <i class="fa fa-chevron-right mt-2 mr-3 fntt2"></i> <span>Blog</span></a>
                    <a class="text-decoration-none mt-3 d-flex" href="#"> <i class="fa fa-chevron-right mt-2 mr-3 fntt2"></i> <span> Login</span></a>
                </div>

                <div class="col-12 col-md-6 col-lg-3 mt-5">
                    <h5 class="mb-4 text-white">Usefull Links</h5>
                    <a class="text-decoration-none d-flex" href="#"> <i class="fa fa-chevron-right mt-2 mr-3 fntt2"></i> <span>Terms of Services</span></a>
                    <a class="text-decoration-none mt-3 d-flex" href="#"> <i class="fa fa-chevron-right mt-2 mr-3 fntt2"></i> <span>Privacy Policy</span></a>
                    <a class="text-decoration-none mt-3 d-flex" href="#"> <i class="fa fa-chevron-right mt-2 mr-3 fntt2"></i> <span>Documentation</span></a>
                    <a class="text-decoration-none mt-3 d-flex" href="#"> <i class="fa fa-chevron-right mt-2 mr-3 fntt2"></i> <span> Changelog</span></a>
                    <a class="text-decoration-none mt-3 d-flex" href="#"> <i class="fa fa-chevron-right mt-2 mr-3 fntt2"></i> <span>Components</span></a>
                </div>

                <div class="col-12 col-md-6 col-lg-3 mt-5">
                    <h5 class="mb-4 text-white">Newsletters</h5>
                    <div class="">
                        <p>Sign up and receive the latest tips via email.</p>
                        <form class="">
                            <label class="text-grey2" for="">Write your email <span class="text-danger">*</span></label>
                            <div class="d-flex p-1 pl-3 bg-blue4 rounded-lg">
                                <i class="fas fa-envelope text-grey2 mt-2 pt-1"></i>
                                <input class="form-control bg-blue4 border-0 shadow-none" type="text" name="name" placeholder="Your Email:">
                            </div>
                            <button class="btn btn btn-lg btns7 w-100 mt-3" type="button"><small class="font-weight-bold">Subscribe</small></button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <hr class="bg-grey2">
        <div class="container foot">
            <div class="row left-reveal">
                <div class="col-12 col-md-6 py-3 text-lg-left">
                    <p class="text-grey2">
                    Write ✍️ to us at <a class="text-grey2" href="#">support@cheqd.in</a>
                    </p>
                </div>
                <div class="col-12 col-md-6 py-3 text-center text-lg-right text-muted">
                    <a href="#"><img class="fntt3" src="assets/image/american-ex.png"></a>
                    <a href="#"><img class="fntt3" src="assets/image/discover.png"></a>
                    <a href="#"><img class="fntt3" src="assets/image/master-card.png"></a>
                    <a href="#"><img class="fntt3" src="assets/image/paypal.png"></a>
                    <a href="#"><img class="fntt3" src="assets/image/visa.png"></a>
                </div>
            </div>
        </div>
  </footer>

    <!--scroll-top-->
    <div>
        <a class="scroll-top" href="#"><i class="fa fa-angle-double-up text-white fa-lg px-3 rounded-lg py-3 bg-blue"></i></a>
    </div> 
